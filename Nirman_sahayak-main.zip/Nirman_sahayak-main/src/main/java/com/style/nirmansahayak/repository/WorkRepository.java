package com.style.nirmansahayak.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.style.nirmansahayak.model.Work;
import com.style.nirmansahayak.response.WorkResponse;


@Repository
public interface WorkRepository extends JpaRepository<Work, Integer> {

	
	
	@Query("SELECT new com.style.nirmansahayak.response.WorkResponse(" +
	           "w.workId, w.name, w.typeOfWork, w.workDescription, w.completeAddress, " +
	           "w.noOfLabours, w.quotedPrice, w.postedDateTime, w.district, w.state, " +
	           "w.country, w.postalCode, w.status, u.userId, u.userName, u.userPhone, " +
	           "u.userEmail, w.workImageUrl) " +
	           "FROM Work w " +
	           "JOIN w.user u " +
	           "WHERE w.postalCode = :postalCode AND w.typeOfWork = :typeOfWork")
	List<WorkResponse> findByPostalCodeAndTypeOfWork(Integer postalCode, String typeOfWork);
}
