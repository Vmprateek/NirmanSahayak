package com.style.nirmansahayak.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ServiceProviderDTO {

    private List<ServiceNameDTO> serviceNames;
    private String shopName;
    private String completeAddress;
    private Integer postalCode;
    private Integer userId;
}
