package com.style.nirmansahayak.repository;

import com.style.nirmansahayak.model.MaterialVendor;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MaterialVendorRepository extends JpaRepository<MaterialVendor, Integer> {

    @Query(value = """
        (SELECT mv.shop_name, mv.complete_address, mv.district, mv.state, 
                mv.country, mv.postal_code, u.user_name, u.user_phone, 
                u.user_email, u.profile_image_url, u.experience, 
                u.delivered_projects, u.ongoing_projects 
         FROM material_vendor mv
         JOIN material_name mn ON mv.material_vendor_id = mn.material_vendor_id
         JOIN all_user u ON mv.user_id = u.user_id
        
         WHERE mn.material_name = :materialName
         AND mv.postal_code = :postalCode
         LIMIT 5)
        UNION
        (SELECT mv.shop_name, mv.complete_address, mv.district, mv.state, 
                mv.country, mv.postal_code, u.user_name, u.user_phone, 
                u.user_email, u.profile_image_url, u.experience, 
                u.delivered_projects, u.ongoing_projects
         FROM material_vendor mv
         JOIN material_name mn ON mv.material_vendor_id = mn.material_vendor_id
         JOIN all_user u ON mv.user_id = u.user_id
        
         WHERE mn.material_name = :materialName
         AND mv.district = (SELECT district FROM material_vendor WHERE postal_code = :postalCode LIMIT 1)
         LIMIT 15)
        """, nativeQuery = true)
    List<Object []> findByServiceNameAndPostalOrDistrict(
            @Param("materialName") String materialName, 
            @Param("postalCode") Integer postalCode);
    @Query(value = "SELECT * FROM material_vendor WHERE user_id = :userId LIMIT 1", nativeQuery = true)
	Optional<MaterialVendor> findByUserId(Integer userId);
}
