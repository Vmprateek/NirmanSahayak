package com.style.nirmansahayak.response;
import lombok.Builder;
import lombok.Data;
@Data
@Builder
public class MaterialVendorResponse {
	
	private String  materialName;  
	private String  shopName;  
	private String  completeAddress;
	private String  district;
	private String  state;  
	private String  country;
	private Integer postalCode;
	private String userName;
    private String userPhone;
    private String userEmail;
    private String profileImageUrl;
    private String experience;
    private String deliveredProjects;
    private String ongoingProjects;
    private Integer rating;

}
