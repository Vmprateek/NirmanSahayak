package com.style.nirmansahayak.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CustomerFeedbackDTO {
    private Long id;
    private String customerName;
    private String email;
    private String feedback;
    private Integer rating;
    private String response;
    private boolean resolved;
}
