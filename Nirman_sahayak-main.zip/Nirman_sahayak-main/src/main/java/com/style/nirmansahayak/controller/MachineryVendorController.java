package com.style.nirmansahayak.controller;

import com.style.nirmansahayak.model.MachineryVendor;
import com.style.nirmansahayak.model.ServiceProvider;
import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.repository.MachineryVendorRepository;
import com.style.nirmansahayak.response.MachineryVendorResponse;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.service.MachineryVendorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/api/v1")  // Version 1 added to the URL
public class MachineryVendorController {

    @Autowired
    private MachineryVendorService machineryVendorService;
    @Autowired
    MachineryVendorRepository machineryVendorRepository;
    // Save Machinery Vendor
    @PostMapping("/saveMachineryVendor")
    public ResponseEntity<?> saveMachineryVendor(@RequestBody MachineryVendor machineryVendor) {
        try {
        	
        	
			Optional<MachineryVendor> existingProvider = machineryVendorRepository
					.findByUserId(machineryVendor.getUser().getUserId());
        	
        	if (existingProvider.isPresent()) {
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK,
                        ResponseCodeEnum.DUPLICATE_ENTRY, 
                        "A machinery vendor is already registered with this user ID.",
                        existingProvider.get()
                );
            }
            log.info("Saving machinery vendor: {}", machineryVendor);
            MachineryVendor savedMachineryVendor = machineryVendorService.saveMachineryVendor(machineryVendor);
            log.info("Successfully saved machinery vendor");
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "Machinery vendor saved successfully",
                    savedMachineryVendor
            );
        } catch (Exception e) {
            log.error("Error saving machinery vendor", e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Failed to save machinery vendor",
                    null
            );
        }
    }

    @GetMapping("/findByMachineryNameAndLocation")
    public ResponseEntity<?> findByMachineryName(
            @RequestParam (required = false)  String machineryName, 
            @RequestParam(required = false)   Integer postalCode,
            @RequestParam(required = false)   String district
            ) {

        // Log the incoming parameters for debugging
        log.info("Method: findByMachineryName, Layer: Controller, Request: Find vendors for machinery: {}, postalCode :{}, district: {}",
                 machineryName, postalCode,district);

        try {
            // Call the service method to find vendors by machinery name and district
            List<MachineryVendorResponse> vendors = machineryVendorService.findByMachineryNameAndLocation(machineryName,postalCode, district);

            // If no vendors are found
            if (vendors.isEmpty()) {
                log.warn("No vendors found for machinery: {}, district: {}", machineryName, district);
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK,
                        ResponseCodeEnum.NO_CONTENT,
                        "No vendors found for machinery: " + machineryName,
                        Collections.emptyList()
                );
            }

            // Successful retrieval
            log.info("Found {} vendors for machinery: {}, district: {}", vendors.size(), machineryName, district);
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "Vendors fetched successfully",
                    vendors
            );
        } catch (Exception e) {
            log.error("Error finding vendors for machinery: {}, district: {}", machineryName, district, e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Error finding vendors for machinery",
                    null
            );
        }
    }


    
}
