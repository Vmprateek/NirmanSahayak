package com.style.nirmansahayak.utils;

import org.springframework.stereotype.Component;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
@Component
public class TwilioSMS {

	

    // Your Twilio Account SID and Auth Token
    public static final String ACCOUNT_SID = "AC3f22b7146c4912af4200b56791f0c92e";
    public static final String AUTH_TOKEN = "ca4d759a479c99877ec26b6242659948";
    public static final String TWILIO_PHONE_NUMBER = "+18159164770"; // Your Twilio number

    public  void sendMessage(String msg,String phoneNumber ) {
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

        // Send the SMS
        Message message = Message.creator(
                new PhoneNumber(phoneNumber),  // To phone number
                new PhoneNumber(TWILIO_PHONE_NUMBER), // From Twilio phone number
                msg)  // Message body
            .create();

        // Print the SID of the sent message
        System.out.println("Message SID: " + message.getSid());
    }
}
