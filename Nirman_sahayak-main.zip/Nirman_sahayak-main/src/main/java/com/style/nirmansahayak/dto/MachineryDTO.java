package com.style.nirmansahayak.dto;

import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MachineryDTO {
	
    private Integer machineryId;   
    public String shopName ;
    public String shopAddress;
    public String typeOfMachinery;
    public String machineryDescription;
    public List<String> machineryImageUrl;
    public String quotedPrice;
    private Integer userId;
    private String userName;
    private String userPhone;
    private String userEmail;
}
