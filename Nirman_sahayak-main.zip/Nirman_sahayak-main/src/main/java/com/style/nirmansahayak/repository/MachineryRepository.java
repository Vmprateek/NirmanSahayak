package com.style.nirmansahayak.repository;

import com.style.nirmansahayak.model.Machinery;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

@Repository
public interface MachineryRepository extends JpaRepository<Machinery, Integer> {

    @Query(value = """
            SELECT 
                m.machinery_id,
                m.type_of_machinery,
                m.machinery_description,
                m.machinery_image_url,
                m.quoted_price,
                u.user_id,
                u.user_name,
                u.user_phone,
                u.user_email,
                u.profile_image_url,
                mv.shop_name,
                mv.postal_code
            FROM machinery m
            JOIN all_user u ON m.user_id = u.user_id
            JOIN machinery_vendor mv ON u.user_id = mv.user_id
            WHERE mv.postal_code = :postalCode
              AND m.type_of_machinery = :typeOfMachinery
            LIMIT 10
        """, nativeQuery = true)
    List<Object[]> findMachineryByPostalCode(
        @Param("postalCode") Integer postalCode,
        @Param("typeOfMachinery") String typeOfMachinery
    );
}
