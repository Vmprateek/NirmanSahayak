package com.style.nirmansahayak.service;

import com.style.nirmansahayak.dto.PostalDetails;
import com.style.nirmansahayak.model.MaterialVendor;
import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.repository.MaterialVendorRepository;
import com.style.nirmansahayak.repository.UserRepository;
import com.style.nirmansahayak.response.MaterialVendorResponse;
import com.style.nirmansahayak.response.ServiceProviderResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
@Slf4j
public class MaterialVendorService {

    @Autowired
    private MaterialVendorRepository materialVendorRepository;
    
    @Autowired
    PostalService postalService;
    @Autowired
    private UserRepository userRepository;

    /**
     * Find material vendors by material name.
     *
     * @param materialName The name of the material.
     * @return List of MaterialVendor objects.
     */
//    public List<MaterialVendor> findByMaterialNameAndLocation(String materialName, String locality, String subLocality) {
//        long startTime = System.currentTimeMillis();
//        log.info("Method: findByMaterialNameAndLocation, Layer: Service, Request: Finding vendors for material: {}, locality: {}, subLocality: {}", 
//                 materialName, locality, subLocality);
//
//        try {
//            // Handle the case where no search criteria are provided
//            if ((materialName == null || materialName.isEmpty()) &&
//                (locality == null || locality.isEmpty()) &&
//                (subLocality == null || subLocality.isEmpty())) {
//                log.warn("Method: findByMaterialNameAndLocation, Layer: Service, No search criteria provided.");
//                return new ArrayList<>();  // Returning an empty list if no parameters are provided
//            }
//
//            // Call repository method with appropriate parameters
//            List<MaterialVendor> vendors = materialVendorRepository.findByMaterialNameAndLocation(materialName, locality, subLocality);
//
//            // Logging based on the result
//            if (vendors.isEmpty()) {
//                log.warn("Method: findByMaterialNameAndLocation, Layer: Service, No vendors found for the given criteria: material: {}, locality: {}, subLocality: {}", 
//                         materialName, locality, subLocality);
//            } else {
//                log.info("Method: findByMaterialNameAndLocation, Layer: Service, Found {} vendors for the given criteria: material: {}, locality: {}, subLocality: {}", 
//                         vendors.size(), materialName, locality, subLocality);
//            }
//
//            return vendors;
//        } catch (Exception e) {
//            log.error("Method: findByMaterialNameAndLocation, Layer: Service, Error finding vendors for the given criteria: material: {}, locality: {}, subLocality: {}", 
//                      materialName, locality, subLocality, e);
//            throw new RuntimeException("Failed to find vendors for material due to internal error", e); // Providing a meaningful exception message
//        } finally {
//            long endTime = System.currentTimeMillis();
//            log.info("Method: findByMaterialNameAndLocation, Layer: Service, Execution Time: {} ms", (endTime - startTime));
//        }
//    }
//

    /**
     * Save a list of material vendors.
     *
     * @param materialVendors The list of material vendors to save.
     * @return List of saved MaterialVendor objects.
     */
    
    
    public MaterialVendor saveMaterialVendor(MaterialVendor materialVendor) {
        long startTime = System.currentTimeMillis();
       // log.info("Method: saveAllMaterialVendors, Layer: Service, Request: Saving list of material vendors. Size: {}", materialVendors.size());

        try {
        	Mono<PostalDetails> data = postalService.getPostalDetails(materialVendor.getPostalCode() );
        	PostalDetails postalDetails = data.block();

        	// Set the district and state values in the serviceProviderInfo object
        	if (postalDetails != null) {
        		materialVendor.setDistrict(postalDetails.getDistrict());
        		materialVendor.setState(postalDetails.getState());
        	} else {
        		materialVendor.setDistrict("Unknown");
        		materialVendor.setState("Unknown");
        	}

        	materialVendor.setCountry("India");
        	materialVendor.setStatus("Active");
        	
        	
        	if (materialVendor.getUser() != null && materialVendor.getUser().getUserId() != null) {
                Integer userId = materialVendor.getUser().getUserId();
                User user = userRepository.findById(userId)
                        .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));

                // Update current service and save User separately
                user.setCurrentService("materialVendor");
                userRepository.save(user); // Explicitly saving user

                // Attach updated user back to materialVendor
                materialVendor.setUser(user);
            }
     MaterialVendor savedVendor = materialVendorRepository.save(materialVendor);
          //  log.info("Method: saveAllMaterialVendors, Layer: Service, Successfully saved {} material vendors", savedVendors.size());
            return savedVendor;
        } catch (Exception e) {
          //  log.error("Method: saveAllMaterialVendors, Layer: Service, Error saving material vendors: {}", materialVendors, e);
            throw new RuntimeException("Failed to save material vendors due to internal error", e); // Providing a meaningful exception message
        } finally {
            long endTime = System.currentTimeMillis();
          //  log.info("Method: saveAllMaterialVendors, Layer: Service, Execution Time: {} ms", (endTime - startTime));
        }
    }

	public List<MaterialVendorResponse> findByMaterialNameAndDistrict(String materialName, Integer postalCode) {
		
		List<Object[]>  data = materialVendorRepository.findByServiceNameAndPostalOrDistrict(materialName,postalCode);
		
		List<MaterialVendorResponse> responseList = new ArrayList<>();
        Integer rating = new Random().nextInt(5) + 1;
        // Loop through each result from the query
        for (Object[] row : data) {
            // Create a new ServiceProviderResponse for each row
        	MaterialVendorResponse materialVendorResponse = MaterialVendorResponse.builder()
                    .shopName((String) row[0])
                    .completeAddress((String) row[1])
                    .district((String) row[2])
                    .state((String) row[3])
                    .country((String) row[4])
                    .postalCode((Integer) row[5])
                    .userName((String) row[6])
                    .userPhone((String) row[7])
                    .userEmail((String) row[8])
                    .profileImageUrl((String) row[9])
                    .experience((String) row[10])
                    .deliveredProjects((String) row[11])
                    .ongoingProjects((String) row[12])
                    .materialName(materialName) // Add the service name to the response
                    .rating(rating)
                    .build();
            // Add the response to the list
            responseList.add(materialVendorResponse);
        }

        // Return the list of responses
        return responseList;
	}


}
