package com.style.nirmansahayak.controller;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.style.nirmansahayak.dto.MachineryRequest;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.model.Machinery;
import com.style.nirmansahayak.model.Material;
import com.style.nirmansahayak.response.MachineryResponse;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.service.MachineryService;
import com.style.nirmansahayak.service.S3Service;
import lombok.extern.slf4j.Slf4j;

@CrossOrigin
@RestController
@Slf4j
@RequestMapping("/api/v1")
public class MachineryController {

	@Autowired
	private MachineryService machineryService;

	@Autowired
	S3Service s3Service;
	ObjectMapper objectMapper = new ObjectMapper();

	@PostMapping("/saveMachinery")
	public ResponseEntity<?> saveMachinery(@RequestPart("machinery") String machineryJson,
			@RequestPart(required = false) List<MultipartFile> files) {
		log.info("Method: saveMachinery, Layer: Controller, Request: Machinery data for shop: {}", machineryJson);
		try {
			log.info("Method: saveMachinery, Layer: Controller, Uploading files to S3 for shop: {}", machineryJson);
			Machinery machinery = objectMapper.readValue(machineryJson, Machinery.class);
			List<String> imageUrls = (files == null || files.isEmpty()) ? null
					: files.stream().map(file -> s3Service.uploadFile(file)) // Assuming s3Service.uploadFile() returns
																				// a URL string
							.collect(Collectors.toList());
			machinery.setMachineryImageUrl(imageUrls); 
			machinery.setStatus("ACTIVE");
			machinery.setPostedDateTime(LocalDateTime.now());
			Machinery savedMachinery = machineryService.saveMachinery(machinery);

			log.info("Method: saveMachinery, Layer: Controller, Success: Machinery saved successfully for shop: {}",
					savedMachinery);
			return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS,
					"Machinery saved successfully", savedMachinery);
		} catch (Exception e) {
			log.error("Method: saveMachinery, Layer: Controller, Error saving machinery for shop: {}", null, e);
			return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR,
					ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error saving machinery", null);
		}
	}

	@GetMapping("/findAllMachineryByLocation")
	public ResponseEntity<?> getAllMachineryByLocation(@RequestParam(required = false) Integer postalCode,@RequestParam(required = false) String typeOfMachinery) {
	    List<MachineryResponse> machineryList = machineryService.getAllMachineryByLocation(postalCode ,typeOfMachinery);

	    if (machineryList.isEmpty()) {
	        return ResponseBuilder.buildResponse(
	                HttpStatus.OK,
	                ResponseCodeEnum.NO_CONTENT,
	                "No machinery found for the given postal code.",
	                Collections.emptyList()
	        );
	    }

	    return ResponseBuilder.buildResponse(
	            HttpStatus.OK,
	            ResponseCodeEnum.SUCCESS,
	            "Machinery data fetched successfully.",
	            machineryList
	    );
	}

	
	@DeleteMapping("/deleteMachinery/{id}")
	public ResponseEntity<?> deleteMachinery(@PathVariable Integer id) {
	    log.info("Method: deleteMachinery, Layer: Controller, Request: Deleting machinery ID: {}", id);

	    try {
	        boolean isDeleted = machineryService.deleteMachinery(id);
	        if (isDeleted) {
	            log.info("Machinery deleted successfully: {}", id);
	            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS,
	                    "Machinery deleted successfully", null);
	        } else {
	            log.warn("Machinery with ID {} not found. Deletion failed.", id);
	            return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND,
	                    "Machinery not found", null);
	        }
	    } catch (Exception e) {
	        log.error("Error deleting machinery ID: {}", id, e);
	        return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR,
	                ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error deleting machinery", null);
	    }
	}
	
	
	

}
