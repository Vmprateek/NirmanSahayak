package com.style.nirmansahayak.controller;

import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.model.Work;
import com.style.nirmansahayak.response.NirmanSahayakResponse;
import com.style.nirmansahayak.service.S3Service;
import com.style.nirmansahayak.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.style.nirmansahayak.dto.WorkRequest;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.exception.ResourceNotFoundException;
import com.style.nirmansahayak.response.*;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.http.MediaType;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;
    @Autowired
    private S3Service s3Service;  // Inject S3Service
    
    ObjectMapper objectMapper = new ObjectMapper();

    // Other existing methods...

    /**
     * Upload a profile image for a user.
     * 
     * @param userId The ID of the user whose profile image is being uploaded.
     * @param file The profile image file.
     * @return Response with the uploaded image URL or failure message.
     * @throws JsonProcessingException 
     * @throws JsonMappingException 
     */
    
    
    @PostMapping(value = "/uploadAllProfileImage/{userId}")
    public String uploadAllProfileImages(
            @PathVariable("userId") Long userId,
            @RequestPart("files") List<MultipartFile> files, 
            @RequestPart("work") String workJson,
            HttpServletRequest request
            
    		) throws JsonMappingException, JsonProcessingException {
    	
    	Work work = objectMapper.readValue(workJson, Work.class);
    	
    	

        // Now you can access the work properties
        System.out.println("Work : " + work);
        System.out.println("Work Description: " + work.getWorkDescription());
    	System.out.println("Received file: " + work);
    	 String contentType = request.getContentType();
    	    System.out.println("Request content type: " + contentType);
        // Log or process the uploaded files for the specific user
        System.out.println("Uploading profile images for user: " + userId);

        for (MultipartFile file : files) {
            // Here, you can handle saving each file
            // Example: Save the file to a specific location
            System.out.println("Received file: " + file.getOriginalFilename());

            // You could add logic to save the file to disk or database
            // For example, using file storage service to save each image
        }

        return "Profile images uploaded successfully for user " + userId;
    }

    
    
    @PostMapping(value = "/uploadProfileImage/{userId}")
    public ResponseEntity<?> uploadProfileImage(
            @PathVariable Integer userId, 
            @RequestParam("file") MultipartFile file) {

        log.info("Method: uploadProfileImage, Layer: Controller, Request: userId = {}, file = {}", userId, file.getOriginalFilename());
        try {
            // Validate file type (optional)
            if (!file.getContentType().startsWith("image")) {
                return ResponseBuilder.buildResponse(HttpStatus.BAD_REQUEST, ResponseCodeEnum.BAD_REQUEST, 
                        "Only image files are allowed", null);
            }

            // Upload the file to S3 using S3Service
            String imageUrl = s3Service.uploadFile(file);

            if (imageUrl.startsWith("Error")) {
                // If there was an error uploading the file
                return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, 
                        imageUrl, null);
            }

            // Update user profile with image URL (Assuming your userService has a method for this)
            userService.updateUserProfileImage(userId, imageUrl);

            // Return the uploaded image URL
            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Profile image uploaded successfully", imageUrl);
            
        } catch (Exception e) {
            log.error("Error uploading profile image for user ID {}: {}", userId, e.getMessage());
            return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, 
                    "Error uploading profile image", null);
        }
    }


    /**
     * Get a user by its ID.
     * 
     * @param id The ID of the user to fetch.
     * @return The user with the given ID.
     * 
     */
    @GetMapping("/findUserById/{id}")
    public ResponseEntity<?> findUserById(@PathVariable Integer id) {
        log.info("Method: findUserById, Layer: Controller, Request: {}", id);
        try { 
            User user = userService.getUserById(id);
            log.info("Method: findUserById, Layer: Controller, Response: {}", user);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            if (user != null) {
            	
            	 List<Object> allItems = new ArrayList<>();
                 allItems.addAll(user.getWorks());
                 allItems.addAll(user.getOpenRequests());
                 allItems.addAll(user.getMaterials());
                 allItems.addAll(user.getMachineries());               
                 Map<String, Object> responseData = new LinkedHashMap<>();
                 responseData.put("userId", user.getUserId());
                 responseData.put("userName", user.getUserName()); // Updated to match actual field
                 responseData.put("userPhone", user.getUserPhone()); // Updated to match actual field
                 responseData.put("userEmail", user.getUserEmail()); // Updated to match actual field
                 responseData.put("profileImageUrl", user.getProfileImageUrl()); // Updated to match actual field
                 responseData.put("experience", user.getExperience()); // Updated to match actual field
                 responseData.put("deliveredProjects", user.getDeliveredProjects()); // Updated to match actual field
                 responseData.put("ongoingProjects", user.getOngoingProjects()); // Updated to match actual field
                 responseData.put("createdAt", user.getCreatedAt() != null ? user.getCreatedAt().format(formatter) : null);
                 responseData.put("currentService", user.getCurrentService()); // Updated to match actual field
                 responseData.put("status", user.getStatus()); // Updated to match actual field
                 responseData.put("activityData", allItems); // Attach combined lis
                return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "User found", user);
            } else {
                return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND, "User not found", null);
            }
        } catch (ResourceNotFoundException e) {
            log.error("User not found with ID: {}", id);
            return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND, e.getMessage(), null);
        }
    }

    /**
     * Save a new user.
     * 
     * @param user The user data to be saved.
     * @return The saved user.
     */
    @PostMapping("/saveUser")
    public ResponseEntity<?> saveUser(@RequestBody User user) {
        log.info("Method: saveUser, Layer: Controller, Request: {}", user);
        try {
            User savedUser = userService.saveUser(user);
            log.info("Method: saveUser, Layer: Controller, Response: {}", savedUser);
            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "User created successfully", savedUser);
        } catch (Exception e) {
            log.error("Error saving user: {}", e.getMessage());
            return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error saving user", null);
        }
    }

    // Other user-related endpoints can follow similar patterns...
    
    
    @PutMapping("/updateUser")
    public ResponseEntity<?> updateUser(@RequestBody User user) {
        log.info("Method: updateUser, Layer: Controller, Request: {}", user);
        try {
            User updatedUser = userService.updateUser(user);
            
            if (updatedUser != null) {
                log.info("Method: updateUser, Layer: Controller, Response: {}", updatedUser);
                return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "User updated successfully", updatedUser);
            } else {
                log.warn("User not found with ID: {}", user.getUserId());
                return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND, "User not found", null);
            }
        } catch (Exception e) {
            log.error("Error updating user: {}", e.getMessage());
            return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error updating user", null);
        }
    }
    
//    @GetMapping("/findAllActivity/{userId}")
//    public ResponseEntity<User> getUserByIdWithActivities(@PathVariable Integer userId) {
//       // User user = userService.getUserByIdWithActivities(userId);
//
//       
//    }
    
    
    

}
 