package com.style.nirmansahayak.response;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MaterialResponse {
    private Integer materialId;
	private String typeOfMaterial;
	private String materialDescription;
	private Double quotedPrice;  	
    private Integer userId;
    private String userName;
    private String userPhone;
    private String userEmail;
    private String profileImageUrl;
    private String shopName;
    private String shopAddress;
	private List<String> materialImageUrl;
}
