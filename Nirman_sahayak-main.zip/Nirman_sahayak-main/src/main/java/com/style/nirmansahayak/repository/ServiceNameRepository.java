package com.style.nirmansahayak.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.style.nirmansahayak.model.ServiceName;

public interface ServiceNameRepository extends JpaRepository<ServiceName, Integer> {

}
