package com.style.nirmansahayak.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.style.nirmansahayak.model.Machinery;
import com.style.nirmansahayak.repository.MachineryRepository;
import com.style.nirmansahayak.response.MachineryResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MachineryService {

    @Autowired
    private MachineryRepository machineryRepository;

    /**
     * Save a new machinery entry.
     *
     * @param machinery The machinery object to save.
     * @return The saved machinery object.
     */
    public Machinery saveMachinery(Machinery machinery) {
        long startTime = System.currentTimeMillis();
        log.info("Method: saveMachinery, Layer: Service, Request: Saving machinery: {}", machinery);

        try {
            Machinery savedMachinery = machineryRepository.save(machinery);
            log.info("Method: saveMachinery, Layer: Service, Success: Machinery saved with ID: {}", savedMachinery.getMachineryId());
            return savedMachinery;
        } catch (Exception e) {
            log.error("Method: saveMachinery, Layer: Service, Error saving machinery: {}", machinery, e);
            throw new RuntimeException("Failed to save machinery due to internal error", e); 
        } finally {
            long endTime = System.currentTimeMillis();
            log.info("Method: saveMachinery, Layer: Service, Execution Time: {} ms", (endTime - startTime));
        }
    }

    /**
     * Get all machinery by postal code.
     *
     * @param postalCode The postal code to filter machinery.
     * @return List of machinery responses.
     */
    public List<MachineryResponse> getAllMachineryByLocation(Integer postalCode ,String typeOfMachinery) {
        List<Object[]> results = machineryRepository.findMachineryByPostalCode(postalCode ,typeOfMachinery);
        List<MachineryResponse> dtoList = new ArrayList<>();

        for (Object[] row : results) {
            MachineryResponse dto = MachineryResponse.builder()
                    .typeOfMachinery((String) row[1])
                    .machineryDescription((String) row[2]) 
                    .quotedPrice((Double) row[4])
                    .userName((String) row[6])
                    .userPhone((String) row[7])
                    .userEmail((String) row[8])
                    .profileImageUrl((String) row[9])
                    .shopName((String) row[10])
                    .shopAddress("test") 
                    .machineryImageUrl(row[3] != null ? Arrays.asList((String[]) row[3]) : new ArrayList<>())
                    .build();
            dtoList.add(dto);
        }
        return dtoList;
    }

    /**
     * Delete machinery by ID.
     *
     * @param id The ID of the machinery to delete.
     * @return true if deleted successfully, false if not found.
     */
    public boolean deleteMachinery(Integer id) {
        log.info("Method: deleteMachinery, Layer: Service, Request: Deleting machinery with ID: {}", id);

        Optional<Machinery> machineryOptional = machineryRepository.findById(id);
        if (machineryOptional.isPresent()) {
            machineryRepository.deleteById(id);
            log.info("Method: deleteMachinery, Layer: Service, Success: Machinery deleted with ID: {}", id);
            return true;
        } else {
            log.warn("Method: deleteMachinery, Layer: Service, Warning: Machinery with ID {} not found", id);
            return false;
        }
    }


    /**
     * Delete machinery by ID.
     *
     * @param id The ID of the machinery to delete.
     * @return true if deleted, false if not found.
     */
    
    

    
}
