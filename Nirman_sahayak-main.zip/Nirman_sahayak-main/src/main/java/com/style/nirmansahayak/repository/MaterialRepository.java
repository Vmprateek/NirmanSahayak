package com.style.nirmansahayak.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.style.nirmansahayak.model.Material;
import org.springframework.data.repository.query.Param;

@Repository
public interface MaterialRepository extends JpaRepository<Material, Integer> {

    @Query(value = """
            SELECT
                m.material_id,
                m.type_of_material,
                m.material_description,
                m.material_image_url,
                m.quoted_price,
                u.user_id,
                u.user_name,
                u.user_phone,
                u.user_email,
                u.profile_image_url,
                mv.shop_name,
                mv.postal_code
            FROM material m
            JOIN all_user u ON m.user_id = u.user_id
            JOIN material_vendor mv ON u.user_id = mv.user_id
            WHERE mv.postal_code = :postalCode AND m.type_of_material = :typeOfMaterial
            ORDER BY m.quoted_price ASC
            LIMIT 10
        """, nativeQuery = true)
    List<Object[]> findMaterialsByPostalCode(@Param("postalCode") Integer postalCode, @Param("typeOfMaterial") String typeOfMaterial);
}
