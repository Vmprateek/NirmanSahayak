package com.style.nirmansahayak.constant;

public class AuthConstants {

    public static final String BUSINESS_EXCEPTION_DESC   = "business error";
    public static final String TECHNICAL_EXCEPTION_DESC  = "technical error";
    public static final String SUCCESS_EXCEPTION_DESC    = "success";
    
}
