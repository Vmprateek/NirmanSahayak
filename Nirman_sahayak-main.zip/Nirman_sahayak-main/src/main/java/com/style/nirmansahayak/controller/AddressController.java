//package com.style.nirmansahayak.controller;
//
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//import com.style.nirmansahayak.dto.AddressRequestDTO;
//import com.style.nirmansahayak.dto.AddressResponseDTO;
//import com.style.nirmansahayak.enums.ResponseCodeEnum;
//import com.style.nirmansahayak.exception.ResourceNotFoundException;
//import com.style.nirmansahayak.model.Address;
//import com.style.nirmansahayak.response.ResponseBuilder;
//import com.style.nirmansahayak.service.AddressService;
//import lombok.extern.slf4j.Slf4j;
//
//@RestController
//@RequestMapping("/api/v1") 
//@Slf4j
//public class AddressController {
//
//    @Autowired
//    private AddressService addressService;
//
//    /**
//     * Save a new address.
//     * 
//     * @param address The address data to be saved.
//     * @return The saved address.
//     */
//    @PostMapping("/saveAddress")
//    public ResponseEntity<?> saveAddress(@RequestBody AddressRequestDTO address) {
//        log.info("Method: saveAddress, Layer: Controller, Request: {}", address);
//        AddressResponseDTO savedAddress = addressService.saveAddress(address);
//        log.info("Method: saveAddress, Layer: Controller, Response: {}", savedAddress);
//        return ResponseBuilder.buildResponse(HttpStatus.CREATED, ResponseCodeEnum.SUCCESS, "Address saved successfully", savedAddress);
//    }
//
//    /**
//     * Get all addresses.
//     * 
//     * @return List of all addresses.
//     */
//    @GetMapping("/getAllAddress")
//    public ResponseEntity<?> findAllAddresses() {
//        log.info("Method: findAllAddresses, Layer: Controller");
//        List<Address> addresses = addressService.getAddresss();
//        log.info("Method: findAllAddresses, Layer: Controller, Response: {}", addresses);
//        return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Addresses fetched successfully", addresses);
//    }
//
//    /**
//     * Get an address by its ID.
//     * 
//     * @param id The ID of the address to fetch.
//     * @return The address with the given ID.
//     */
//    
//    @GetMapping("/getAddressById/{id}")
//    public ResponseEntity<?> findAddressById(@PathVariable Integer id) {
//        log.info("Method: findAddressById, Layer: Controller, Request: {}", id);
//        try {
//            Address address = addressService.getAddressById(id);
//            
//            if (address != null) {
//                log.info("Method: findAddressById, Layer: Controller, Response: {}", address);
//                return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Address found", address);
//            } else {
//                log.warn("Method: findAddressById, Layer: Controller, Address not found for ID: {}", id);
//                return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND, "Address not found", null);
//            }
//        } catch (ResourceNotFoundException e) {
//            log.error("Address not found with ID: {}", id, e);
//            return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND, e.getMessage(), null);
//        }
//    }
//
//
//    /**
//     * Update an existing address.
//     * 
//     * @param address The address with updated data.
//     * @return The updated address.
//     */
//    @PutMapping("/updateAddress")
//    public ResponseEntity<?> updateAddress(@RequestBody Address address) {
//        log.info("Method: updateAddress, Layer: Controller, Request: {}", address);
//        Address updatedAddress = addressService.updateAddress(address);
//        log.info("Method: updateAddress, Layer: Controller, Response: {}", updatedAddress);
//        return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Address updated successfully", updatedAddress);
//    }
//
//    /**
//     * Delete an address by its ID.
//     * 
//     * @param id The ID of the address to delete.
//     * @return A success message.
//     */
//    @DeleteMapping("/deleteAddress/{id}")
//    public ResponseEntity<?> deleteAddress(@PathVariable int id) {
//        log.info("Method: deleteAddress, Layer: Controller, Request: {}", id);
//        addressService.deleteAddress(id);
//        log.info("Method: deleteAddress, Layer: Controller, Response: Address deleted successfully");
//        return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Address deleted successfully", null);
//    }
//
//    /**
//     * Find an address by its pin code.
//     * 
//     * @param pin The pin code to search for.
//     * @return The address with the given pin code.
//     */
//    @GetMapping("/findAddressByPin/{pin}")
//    public ResponseEntity<?> findAddressByPin(@PathVariable int pin) {
//        log.info("Method: findAddressByPin, Layer: Controller, Request: {}", pin);
//        Address address = addressService.findAddressByPin(pin);
//        if (address != null) {
//            log.info("Method: findAddressByPin, Layer: Controller, Response: {}", address);
//            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Address found", address);
//        } else {
//            log.info("Method: findAddressByPin, Layer: Controller, Response: Address not found for pin {}", pin);
//            return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND, "Address not found for the given pin", null);
//        }
//    }
//
//    /**
//     * Search for addresses by city.
//     * 
//     * @param city The city to search for.
//     * @return A list of addresses in the given city.
//     */
//    @GetMapping("/search")
//    public ResponseEntity<?> searchCity(@RequestParam String city) {
//        log.info("Method: searchCity, Layer: Controller, Request: {}", city);
//        List<Address> addresses = addressService.findAddressByCity(city);
//        log.info("Method: searchCity, Layer: Controller, Response: {}", addresses);
//        return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Addresses found for the city", addresses);
//    }
//}
