package com.style.nirmansahayak.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class AddressDTO {
    private Integer addressId;
    private Integer pin;
    private String address1;
    private String address2;
    private String city;
}
