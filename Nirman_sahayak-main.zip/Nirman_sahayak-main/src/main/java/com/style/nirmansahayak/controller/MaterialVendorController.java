package com.style.nirmansahayak.controller;

import com.style.nirmansahayak.model.MaterialName;
import com.style.nirmansahayak.model.MaterialVendor;
import com.style.nirmansahayak.model.ServiceProvider;
import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.repository.MaterialNameRepository;
import com.style.nirmansahayak.repository.MaterialVendorRepository;
import com.style.nirmansahayak.response.MaterialVendorResponse;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.service.MaterialVendorService;
import com.style.nirmansahayak.service.UserService;
import com.style.nirmansahayak.enums.ResponseCodeEnum;

import lombok.extern.slf4j.Slf4j;

import org.hibernate.sql.ast.tree.expression.Collation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("/api/v1")
@Slf4j
public class MaterialVendorController {

    @Autowired
    private MaterialVendorService materialVendorService;

    
    @Autowired
    MaterialVendorRepository materialVendorRepository;
    
   @Autowired
   MaterialNameRepository materialNameRepository;
    /**
     * Saves a list of material vendors.
     *
     * @param materialVendors List of MaterialVendor objects to save.
     * @return ResponseEntity containing the saved material vendors.
     */
    @PostMapping("/saveMaterialVendor")
    public ResponseEntity<?> createAllMaterialVendors(@RequestBody MaterialVendor materialVendor) {
        try {
        	
			Optional<MaterialVendor> existingProvider = materialVendorRepository
					.findByUserId(materialVendor.getUser().getUserId());
        	
        	if (existingProvider.isPresent()) {
              //  log.warn("Service Provider already exists for user ID: {}", serviceProviderInfo.getUserId());
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK, // 409 Conflict
                        ResponseCodeEnum.DUPLICATE_ENTRY, 
                        "A Material vendor is already registered with this user ID.",
                        existingProvider.get()
                );
            }
        	
            MaterialVendor savedMaterialVendors = materialVendorService.saveMaterialVendor(materialVendor);
            log.info("Successfully saved all material vendors");
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "All material vendors saved successfully",
                    savedMaterialVendors
            );
        } catch (Exception e) {
            log.error("Error saving all material vendors", e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Failed to save material vendors",
                    null
            );
        }
    }

    @GetMapping("/findByMaterialNameAndLocation")
    public ResponseEntity<?> findByMaterialNameAndLocation(
        @RequestParam(required = false) String materialName,
        @RequestParam(required = false) Integer postalCode
        ) {

        try {
            // Log the incoming parameters for debugging
            log.info("Fetching material vendors for material name: {}, postalCode,{} district: {}", materialName,postalCode);

            
            
            List<MaterialVendorResponse> vendors = materialVendorService.findByMaterialNameAndDistrict(materialName,postalCode);

            // If no vendors are found
            if (vendors.isEmpty()) {
                log.warn("No vendors found for the given criteria.");
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK,
                        ResponseCodeEnum.NO_CONTENT,
                        "No vendors found for the given search criteria",
                        Collections.emptyList()
                        
                );
            }

            // Successful retrieval
            log.info("Found {} vendors for the given search criteria.", vendors.size());
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "Vendors fetched successfully",
                    vendors
            );
        } catch (Exception e) {
            log.error("Error fetching material vendors by material name and location", e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Failed to fetch material vendors",
                    null
            );
        }
    }

    @PutMapping("/updateMaterialList")
    public ResponseEntity<?> updateMaterialList(@RequestBody MaterialVendor materialVendor) {
        try {
            Integer vendorId = materialVendor.getMaterialVendorId();
            Optional<MaterialVendor> existingVendorOpt = materialVendorRepository.findById(vendorId);

            if (existingVendorOpt.isPresent()) {
                MaterialVendor existingVendor = existingVendorOpt.get();

                // ✅ Step 1: Delete old materials
                materialNameRepository.deleteAllByMaterialVendorId(vendorId);

                // ✅ Step 2: Assign new materials to vendor
                if (materialVendor.getMaterialNames() != null) {
                    for (MaterialName material : materialVendor.getMaterialNames()) {
                        material.setMaterialVendor(existingVendor); // Link material to vendor
                    }
                }

                // ✅ Step 3: Save updated vendor with new materials
                existingVendor.setMaterialNames(materialVendor.getMaterialNames());
                MaterialVendor savedVendor = materialVendorRepository.save(existingVendor);

                log.info("Material list updated successfully for vendor ID: {}", vendorId);
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK,
                        ResponseCodeEnum.SUCCESS,
                        "Material list updated successfully",
                        savedVendor
                );
            } else {
                log.warn("Material Vendor not found with ID: {}", vendorId);
                return ResponseBuilder.buildResponse(
                        HttpStatus.NOT_FOUND,
                        ResponseCodeEnum.NOT_FOUND,
                        "Material vendor not found",
                        null
                );
            }
        } catch (Exception e) {
            log.error("Error updating material list for vendor ID: {}", materialVendor.getMaterialVendorId(), e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Failed to update material list",
                    null
            );
        }
    }



}
