package com.style.nirmansahayak.model;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Machinery {
    @Id
    @GeneratedValue
    private Integer machineryId;    
    private String typeOfMachinery;
    private String machineryDescription;
    private Double quotedPrice; 
    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDateTime postedDateTime;
    private String status;
    private List<String> machineryImageUrl;
    private String type;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonBackReference
    private User user;
}
