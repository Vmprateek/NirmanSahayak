//package com.style.nirmansahayak.service;
//
//import com.style.nirmansahayak.dto.CustomerFeedbackDTO;
//import com.style.nirmansahayak.model.CustomerFeedback;
//import com.style.nirmansahayak.repository.CustomerFeedbackRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.stream.Collectors;
//
//@Service
//public class CustomerFeedbackService {
//
//    private final CustomerFeedbackRepository feedbackRepository;
//
//    @Autowired
//    public CustomerFeedbackService(CustomerFeedbackRepository feedbackRepository) {
//        this.feedbackRepository = feedbackRepository;
//    }
//
//    // Save feedback
//    public CustomerFeedbackDTO saveFeedback(CustomerFeedbackDTO feedbackDTO) {
//        CustomerFeedback feedback = new CustomerFeedback();
//        feedback.setCustomerName(feedbackDTO.getCustomerName());
//        feedback.setEmail(feedbackDTO.getEmail());
//        feedback.setFeedback(feedbackDTO.getFeedback());
//        feedback.setRating(feedbackDTO.getRating());
//        feedback.setResolved(false);
//
//        feedback = feedbackRepository.save(feedback);
//
//        return new CustomerFeedbackDTO(feedback.getId(), feedback.getCustomerName(), feedback.getEmail(),
//                feedback.getFeedback(), feedback.getRating(), feedback.getResponse(), feedback.isResolved());
//    }
//
//    // Get all feedback
//    public List<CustomerFeedbackDTO> getAllFeedback() {
//        List<CustomerFeedback> feedbackList = feedbackRepository.findAll();
//        return feedbackList.stream().map(feedback -> new CustomerFeedbackDTO(
//                feedback.getId(), feedback.getCustomerName(), feedback.getEmail(),
//                feedback.getFeedback(), feedback.getRating(), feedback.getResponse(), feedback.isResolved()))
//                .collect(Collectors.toList());
//    }
//
//    // Get feedback by ID
//    public CustomerFeedbackDTO getFeedbackById(Long id) {
//        CustomerFeedback feedback = feedbackRepository.findById(id).orElse(null);
//        if (feedback != null) {
//            return new CustomerFeedbackDTO(feedback.getId(), feedback.getCustomerName(), feedback.getEmail(),
//                    feedback.getFeedback(), feedback.getRating(), feedback.getResponse(), feedback.isResolved());
//        }
//        return null;
//    }
//
//    // Update feedback response and resolved status
//    public CustomerFeedbackDTO updateFeedbackResponse(Long id, String response, boolean resolved) {
//        CustomerFeedback feedback = feedbackRepository.findById(id).orElse(null);
//        if (feedback != null) {
//            feedback.setResponse(response);
//            feedback.setResolved(resolved);
//            feedback = feedbackRepository.save(feedback);
//
//            return new CustomerFeedbackDTO(feedback.getId(), feedback.getCustomerName(), feedback.getEmail(),
//                    feedback.getFeedback(), feedback.getRating(), feedback.getResponse(), feedback.isResolved());
//        }
//        return null;
//    }
//}
