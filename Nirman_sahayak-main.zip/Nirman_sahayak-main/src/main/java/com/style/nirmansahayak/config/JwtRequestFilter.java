package com.style.nirmansahayak.config;

import com.style.nirmansahayak.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@Component
public class JwtRequestFilter extends OncePerRequestFilter {

    @Autowired
    private JwtUtil jwtUtil;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String requestURI = request.getRequestURI();

        // Skip filtering for OTP-related APIs
      if (requestURI.startsWith("/api/v1/verifyOtp") || requestURI.startsWith("/api/v1/sendOtp") || requestURI.startsWith("/api/v1")) {
        //if (requestURI.startsWith("/api/v1/verifyOtp") || requestURI.startsWith("/api/v1/sendOtp")) {
           chain.doFilter(request, response);
            return;
        }
        String authorizationHeader = request.getHeader("Authorization");

        try {
            if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
                sendResponse(response, HttpStatus.FORBIDDEN, "Authorization token is missing", false);
                return;
            }

            String token = authorizationHeader.substring(7);
            String phoneNumber;

            boolean isTokenExpired = jwtUtil.isTokenExpired(token);
            if (isTokenExpired) {
                sendResponse(response, HttpStatus.UNAUTHORIZED, "Token expired or invalid, please re-login", true);
                return;
            }
            // Validate token
            if (jwtUtil.validateToken(token)) {
                phoneNumber = jwtUtil.extractPhoneNumber(token);
                if (phoneNumber != null) {
                    SecurityContextHolder.getContext()
                            .setAuthentication(new JwtAuthenticationToken(phoneNumber, null));
                    chain.doFilter(request, response);
                } else {
                    sendResponse(response, HttpStatus.UNAUTHORIZED, "Failed to extract phone number from token", isTokenExpired);
                }
            } else {
                // Invalid or manipulated token
                sendResponse(response, HttpStatus.FORBIDDEN, "Invalid or manipulated token", isTokenExpired);
            }

        } catch (Exception e) {
            // Log exception for debugging purposes
            e.printStackTrace();
            sendResponse(response, HttpStatus.INTERNAL_SERVER_ERROR,
                    "An error occurred during authentication: " + e.getMessage(), false);
        }
    }

    private void sendResponse(HttpServletResponse response, HttpStatus status, String message, boolean isTokenExpired) throws IOException {
        // Construct the response body manually including the isTokenExpired field
        String responseBody = String.format("{\"code\": %d, \"status\": \"%s\", \"desc\": \"%s\", \"error\": null, \"data\": null, \"isTokenExpired\": %b}",
                status.value(), status.getReasonPhrase(), message, isTokenExpired);

        // Set the response status using HttpServletResponse
        response.setStatus(status.value());

        // Set the content type
        response.setContentType("application/json");

        // Write the response body (using response.getWriter())
        try (var writer = response.getWriter()) {
            writer.write(responseBody);
        }
    }
}
