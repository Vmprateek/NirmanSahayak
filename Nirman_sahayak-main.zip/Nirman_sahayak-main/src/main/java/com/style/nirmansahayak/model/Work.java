package com.style.nirmansahayak.model;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Work {

   	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
	@SequenceGenerator(name = "user_sequence", sequenceName = "user_sequence", initialValue = 1, allocationSize = 1)
    private Integer workId;
    private String name;
    private String typeOfWork;
    private String workDescription;
    private String  completeAddress;
    private Integer noOfLabours;
    private Double  quotedPrice;
    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDateTime postedDateTime;   
    private String  district;
    private String  state;  
    private String  country;
    private Integer postalCode;  
    private String  status; 
    private List<String> workImageUrl;
    private String type;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonBackReference
    private User user;
}