package com.style.nirmansahayak.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Slf4j  // Lombok's annotation to generate the logger
@Service
public class HomePageService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public String getHomePageData() {
        // Updated SQL query with the correct column name
        String sql = "SELECT json_object_agg(service_name, items) AS result \r\n"
                + "FROM ( \r\n"
                + "    SELECT service_name, \r\n"
                + "           json_agg(\r\n"
                + "               jsonb_build_object(\r\n"
                + "                   'id', id, \r\n"
                + "                   'name', name, \r\n"
                + "                   'src', src, \r\n"
                + "                   'service_name', service_name\r\n"
                + "               ) ORDER BY id\r\n"
                + "           ) AS items \r\n"
                + "    FROM home_page \r\n"
                + "    GROUP BY service_name \r\n"
                + ") AS grouped_data;";

        try {
            // Execute the query and retrieve the result as a JSON string directly
            String jsonResult = jdbcTemplate.queryForObject(sql, String.class);

            // If the result is not null, return it, otherwise log a warning
            if (jsonResult != null) {
                log.info("Query executed successfully, returning result: {}", jsonResult);
                return jsonResult;  // Return the JSON string
            } else {
                log.warn("Query result is null, returning empty JSON.");
                return "{}";  // Return an empty JSON object in case of failure
            }

        } catch (DataAccessException e) {
            // Log the exception with error level using SLF4J
            log.error("Error executing SQL query: {}", e.getMessage(), e);
            return "{\"error\": \"Failed to retrieve data\"}"; // Return a controlled error response
        }
    }
}
