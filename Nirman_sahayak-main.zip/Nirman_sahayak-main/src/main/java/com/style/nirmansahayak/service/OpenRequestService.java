package com.style.nirmansahayak.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.style.nirmansahayak.model.OpenRequest;
import com.style.nirmansahayak.repository.OpenRequestRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class OpenRequestService {

    @Autowired
    private OpenRequestRepository openRequestRepository;

    public OpenRequest saveOpenRequest(OpenRequest openRequest) {
        log.info("Method: saveOpenRequest, Layer: Service, Request: Saving OpenRequest for postal code: {}", openRequest.getPostalCode());
        OpenRequest savedRequest = openRequestRepository.save(openRequest);
        log.info("Method: saveOpenRequest, Layer: Service, Success: OpenRequest saved with ID: {}", savedRequest.getOpenRequestId());
        return savedRequest;
    }

    public List<OpenRequest> getOpenRequestsByLocation(Integer postalCode) {
        log.info("Method: getOpenRequestsByLocation, Layer: Service, Request: Fetching OpenRequests for postal code: {}", postalCode);
        List<OpenRequest> openRequests = openRequestRepository.findByPostalCode(postalCode);
        
        if (openRequests.isEmpty()) {
            log.warn("Method: getOpenRequestsByLocation, Layer: Service, Warning: No OpenRequests found for postal code: {}", postalCode);
        } else {
            log.info("Method: getOpenRequestsByLocation, Layer: Service, Success: Found {} OpenRequests for postal code: {}", openRequests.size(), postalCode);
        }
        
        return openRequests;
    }

    public boolean deleteOpenRequest(Integer id) {
        log.info("Method: deleteOpenRequest, Layer: Service, Request: Deleting OpenRequest with ID: {}", id);
        
        Optional<OpenRequest> openRequestOptional = openRequestRepository.findById(id);
        if (openRequestOptional.isPresent()) {
            openRequestRepository.deleteById(id);
            log.info("Method: deleteOpenRequest, Layer: Service, Success: OpenRequest deleted with ID: {}", id);
            return true;
        } else {
            log.warn("Method: deleteOpenRequest, Layer: Service, Warning: OpenRequest with ID {} not found", id);
            return false;
        }
    }
}
