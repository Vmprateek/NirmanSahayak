package com.style.nirmansahayak.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.style.nirmansahayak.dto.ImageUpload;
import com.style.nirmansahayak.model.MachineryName;
import com.style.nirmansahayak.model.MaterialName;
import com.style.nirmansahayak.model.ServiceName;
import com.style.nirmansahayak.model.Work;
import com.style.nirmansahayak.repository.MachineryNameRepository;
import com.style.nirmansahayak.repository.MaterialNameRepository;
import com.style.nirmansahayak.repository.ServiceNameRepository;
import com.style.nirmansahayak.service.S3Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class S3Controller {

    private final S3Service s3Service;
    
    @Autowired
    private ServiceNameRepository serviceNameRepository;
    
    @Autowired
    private MaterialNameRepository materialNameRepository;
    @Autowired
    private MachineryNameRepository machineryNameRepository;
    
    ObjectMapper objectMapper = new ObjectMapper();
    
    public S3Controller(S3Service s3Service) {
        this.s3Service = s3Service;
    }

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@RequestParam("file") MultipartFile file) {
        String fileUrl = s3Service.uploadFile(file);
        return ResponseEntity.ok(fileUrl);
    }

    @PostMapping("/uploadMultiple")
    public ResponseEntity<List<String>> uploadMultipleFiles(
            @RequestParam("files") MultipartFile[] files,
            @RequestPart("request") String request) throws JsonMappingException, JsonProcessingException {
        
        List<String> uploadedUrls = new ArrayList<>();

        // Upload all files to S3
        for (MultipartFile file : files) {
            String fileUrl = s3Service.uploadFile(file);
            uploadedUrls.add(fileUrl);
        }

        // Parse request JSON into ImageUpload object
        ImageUpload imageUpload = objectMapper.readValue(request, ImageUpload.class);

        // Process based on the type field
        switch (imageUpload.getType().toLowerCase()) {
            case "serviceprovider":
                ServiceName serviceName = new ServiceName();
                serviceName.setServiceName(imageUpload.getServiceName());
                serviceName.setServiceImageUrl(uploadedUrls);
                serviceNameRepository.save(serviceName);
                break;
            
            case "material":
                MaterialName materialName = new MaterialName();
                materialName.setMaterialName(imageUpload.getMaterialName());
                materialName.setMaterialImageUrl(uploadedUrls);
                materialNameRepository.save(materialName);
                break;

            case "machinery":
                MachineryName machineryName = new MachineryName();
                machineryName.setMachineryName(imageUpload.getMachineryName());
                machineryName.setMachineryImageUrl(uploadedUrls);
                machineryNameRepository.save(machineryName);
                break;

            default:
                return ResponseEntity.badRequest().body(null);
        }

        return ResponseEntity.ok(uploadedUrls);
    }


}
