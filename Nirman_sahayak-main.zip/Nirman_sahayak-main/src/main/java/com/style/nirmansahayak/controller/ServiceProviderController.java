package com.style.nirmansahayak.controller;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.model.ServiceProvider;
import com.style.nirmansahayak.repository.ServiceProviderRepository;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.response.ServiceProviderResponse;
import com.style.nirmansahayak.service.ServiceProviderService;

import lombok.extern.slf4j.Slf4j;

@CrossOrigin
@RestController
@RequestMapping("/api/v1")  // Version 1 added to the URL
@Slf4j
public class ServiceProviderController {

    @Autowired
    private ServiceProviderService serviceProviderService;
    
    @Autowired
    ServiceProviderRepository serviceProviderInfoRepository;

    /**
     * Save a list of service providers.
     *
     * @param serviceProviderList List of ServiceProvider objects to save.
     * @return ResponseEntity with saved service providers.
     */
    
    @PostMapping("/saveServiceProvider")
    public ResponseEntity<?> saveServiceProvider(@RequestBody ServiceProvider serviceProviderInfo) {
        try {
        	
        	
        	
			Optional<ServiceProvider> existingProvider = serviceProviderInfoRepository
					.findByUserId(serviceProviderInfo.getUser().getUserId());
        	
        	if (existingProvider.isPresent()) {
              //  log.warn("Service Provider already exists for user ID: {}", serviceProviderInfo.getUserId());
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK, // 409 Conflict
                        ResponseCodeEnum.DUPLICATE_ENTRY, 
                        "A service provider already exists for this user ID.",
                        existingProvider.get()
                );
            }

        	
        	
        	
            log.info("Attempting to save ServiceProvider: {}", serviceProviderInfo);
            ServiceProvider savedServiceProvider = serviceProviderService.saveServiceProvider(serviceProviderInfo);
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "Service provider saved successfully.",
                    savedServiceProvider
            );
        } catch (Exception e) {
            log.error("Error saving ServiceProvider: {}", e.getMessage(), e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Failed to save service provider.",
                    null
            );
        }
    }

    /**
     * Find service providers by service name.
     *
     * @param serviceName The name of the service to search for.
     * @return ResponseEntity with the list of service providers or an error response.
     */
    @GetMapping("/findByServiceNameAndLocation")
    public ResponseEntity<?> findByServiceNameAndLocation(
            @RequestParam(required = false) String serviceName, 
            @RequestParam(required = false) Integer postalCode,            
            @RequestParam(required = false) String district) {

        log.info("Searching for ServiceProviders with serviceName: {}, postalCode: {}, district: {}", 
                serviceName, postalCode, district); 

        try {
            List<ServiceProviderResponse> serviceProviders = serviceProviderService.findByServiceNameAndLocation(serviceName,postalCode, district);
            if (serviceProviders.isEmpty()) {
                log.warn("No ServiceProviders found for serviceName: {}, district: {}", serviceName, district);
                return ResponseBuilder.buildResponse(
                        HttpStatus.OK,
                        ResponseCodeEnum.NO_CONTENT, 
                        "No service providers found for the specified service name and district.",
                        Collections.emptyList() 
                );
            }

            // Successful retrieval
            log.info("Found {} ServiceProviders for serviceName: {}, district: {}", serviceProviders.size(), serviceName, district);
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "Service providers fetched successfully.",
                    serviceProviders
            );
        } catch (Exception e) {
            log.error("Error fetching ServiceProviders by serviceName and district: {}", e.getMessage(), e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "Failed to fetch service providers.",
                    null
            );
        }
    }

}
