package com.style.nirmansahayak.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.style.nirmansahayak.model.MachineryName;

public interface MachineryNameRepository extends JpaRepository<MachineryName, Integer>{

}
