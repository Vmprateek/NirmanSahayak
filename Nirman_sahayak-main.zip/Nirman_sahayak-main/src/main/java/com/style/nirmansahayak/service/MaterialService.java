package com.style.nirmansahayak.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.style.nirmansahayak.dto.MaterialDTO;
import com.style.nirmansahayak.model.Material;
import com.style.nirmansahayak.repository.MaterialRepository;
import com.style.nirmansahayak.response.MaterialResponse;

import lombok.Builder;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MaterialService {

    @Autowired
    private MaterialRepository materialRepository;

    /**
     * Save a new material entry.
     *
     * @param material The material object to save.
     * @return The saved material object.
     */
    public Material saveMaterial(Material material) {
        long startTime = System.currentTimeMillis();
        log.info("Method: saveMaterial, Layer: Service, Request: Saving material: {}", material);

        try {
        	
        	material.setType("Material");
            Material savedMaterial = materialRepository.save(material);
            log.info("Method: saveMaterial, Layer: Service, Success: Material saved with ID: {}", savedMaterial.getMaterialId());
            return savedMaterial;
        } catch (Exception e) {
            log.error("Method: saveMaterial, Layer: Service, Error saving material: {}", material, e);
            throw new RuntimeException("Failed to save material due to internal error", e); // Providing a meaningful exception message
        } finally {
            long endTime = System.currentTimeMillis();
            log.info("Method: saveMaterial, Layer: Service, Execution Time: {} ms", (endTime - startTime));
        }
    }

    public List<MaterialResponse> getMaterialsByLocation(Integer postalCode, String typeOfMaterial) {  	
    	List<Object[]> results = materialRepository.findMaterialsByPostalCode(postalCode ,typeOfMaterial);       
        List<MaterialResponse> dtoList = new ArrayList<>();
        
        for (Object[] row : results) {
        	System.out.println((String) row[1]);
        	MaterialResponse dto = MaterialResponse.builder()
                    .materialId((Integer) row[0]) 
                    .typeOfMaterial((String) row[1]) 
                    .materialDescription((String) row[2]) 
                    .materialImageUrl(row[3] != null ? Arrays.asList((String[]) row[3]) : new ArrayList<>()) // Null check
                    .quotedPrice((Double) row[4]) 
                    .userId((Integer) row[5]) 
                    .userName((String) row[6]) 
                    .userPhone((String) row[7]) 
                    .userEmail((String) row[8]) 
                    .profileImageUrl((String) row[9]) 
                    .shopName((String) row[10])  
                    .shopAddress("10B,newtown kolkata ")
                    .build();
            dtoList.add(dto);
        }
        return dtoList;
    }
    
    
    
    public boolean deleteMaterial(Integer materialId) {
        if (materialRepository.existsById(materialId)) {
            materialRepository.deleteById(materialId);
            return true;
        }
        return false;
    }

    /**
     * Fetch materials near a specified location within a given radius.
     *
     * @param latitude  The latitude of the location.
     * @param longitude The longitude of the location.
     * @param radius    The radius in kilometers to search within.
     * @return List of materials near the given location.
     */
//    public List<Material> getMaterialsNearLocation(Double latitude, Double longitude, Double radius) {
//        long startTime = System.currentTimeMillis();
//        log.info("Method: getMaterialsNearLocation, Layer: Service, Request: Fetching materials near location: latitude={}, longitude={}, radius={}", latitude, longitude, radius);
//
//        try {
//            List<Material> materialsList = materialRepository.findMaterialsNearLocation(latitude, longitude, radius);
//            
//            if (materialsList.isEmpty()) {
//                log.warn("Method: getMaterialsNearLocation, Layer: Service, No materials found near location: latitude={}, longitude={}, radius={}", latitude, longitude, radius);
//            } else {
//                log.info("Method: getMaterialsNearLocation, Layer: Service, Found {} materials near the location", materialsList.size());
//            }
//            
//            return materialsList;
//        } catch (Exception e) {
//            log.error("Method: getMaterialsNearLocation, Layer: Service, Error fetching materials near location: latitude={}, longitude={}, radius={}", latitude, longitude, radius, e);
//            throw new RuntimeException("Failed to fetch materials near location due to internal error", e); // Providing a meaningful exception message
//        } finally {
//            long endTime = System.currentTimeMillis();
//            log.info("Method: getMaterialsNearLocation, Layer: Service, Execution Time: {} ms", (endTime - startTime));
//        }
//    }
}
