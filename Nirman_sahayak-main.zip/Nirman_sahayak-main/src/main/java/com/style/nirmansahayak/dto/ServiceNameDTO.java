package com.style.nirmansahayak.dto;

import lombok.Data;

@Data
public class ServiceNameDTO {
	 private String serviceName;
}
