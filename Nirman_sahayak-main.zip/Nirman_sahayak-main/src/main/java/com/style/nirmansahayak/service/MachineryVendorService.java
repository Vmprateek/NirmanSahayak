package com.style.nirmansahayak.service;

import com.style.nirmansahayak.dto.PostalDetails;
import com.style.nirmansahayak.model.MachineryVendor;
import com.style.nirmansahayak.repository.MachineryVendorRepository;
import com.style.nirmansahayak.response.MachineryVendorResponse;
import com.style.nirmansahayak.response.MaterialVendorResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
@Slf4j
public class MachineryVendorService {

    @Autowired
    private MachineryVendorRepository machineryVendorRepository;
    @Autowired
    PostalService postalService;
    /**
     * Find machinery vendors by machinery name.
     *
     * @param machineryName The name of the machinery.
     * @return List of MachineryVendor objects.
     */
////    public List<MachineryVendor> findByMachineryName(String machineryName) {
////        long startTime = System.currentTimeMillis();
////        log.info("Method: findByMachineryName, Layer: Service, Request: Finding vendors for machinery: {}", machineryName);
////
////        try {
////            List<MachineryVendor> vendors = machineryVendorRepository.findByMachineryName(machineryName);
////            if (vendors.isEmpty()) {
////                log.warn("Method: findByMachineryName, Layer: Service, No vendors found for machinery: {}", machineryName);
////            } else {
////                log.info("Method: findByMachineryName, Layer: Service, Found {} vendors for machinery: {}", vendors.size(), machineryName);
////            }
////            return vendors;
////        } catch (Exception e) {
////            log.error("Method: findByMachineryName, Layer: Service, Error finding vendors for machinery: {}", machineryName, e);
////            throw new RuntimeException("Failed to find vendors for machinery due to internal error", e); // Providing a meaningful exception message
////        } finally {
////            long endTime = System.currentTimeMillis();
////            log.info("Method: findByMachineryName, Layer: Service, Execution Time: {} ms", (endTime - startTime));
////        }
//    }

    /**
     * Save a list of machinery vendors.
     *
     * @param machineryVendors The list of machinery vendors to save.
     * @return List of saved MachineryVendor objects.
     */
    public MachineryVendor saveMachineryVendor(MachineryVendor machineryVendors) {
        long startTime = System.currentTimeMillis();
        //log.info("Method: saveAllMachineryVendors, Layer: Service, Request: Saving list of machinery vendors. Size: {}", machineryVendors.size());

        try {
        	Mono<PostalDetails> data = postalService.getPostalDetails(machineryVendors.getPostalCode());
        	PostalDetails postalDetails = data.block();

        	// Set the district and state values in the serviceProviderInfo object
        	if (postalDetails != null) {
        		machineryVendors.setDistrict(postalDetails.getDistrict());
        		machineryVendors.setState(postalDetails.getState());
        	} else {
        		machineryVendors.setDistrict("Unknown");
        		machineryVendors.setState("Unknown");
        	}

        	machineryVendors.setCountry("India");
        	machineryVendors.setStatus("Active");
            MachineryVendor savedVendors = machineryVendorRepository.save(machineryVendors);
            //log.info("Method: saveAllMachineryVendors, Layer: Service, Successfully saved {} machinery vendors", savedVendors.size());
            return savedVendors;
        } catch (Exception e) {
            log.error("Method: saveAllMachineryVendors, Layer: Service, Error saving machinery vendors: {}", machineryVendors, e);
            throw new RuntimeException("Failed to save machinery vendors due to internal error", e); // Providing a meaningful exception message
        } finally {
            long endTime = System.currentTimeMillis();
            log.info("Method: saveAllMachineryVendors, Layer: Service, Execution Time: {} ms", (endTime - startTime));
        }
    }

    public List<MachineryVendorResponse> findByMachineryNameAndLocation(String machineryName, Integer postalCode, String district) {
    	
    	
    	List<Object[]> data=machineryVendorRepository.findByMachineryNameAndPostalOrDistrict(machineryName, postalCode);
    	List<MachineryVendorResponse> responseList = new ArrayList<>();

        // Loop through each result from the query
        for (Object[] row : data) {
            // Create a new ServiceProviderResponse for each row
        	MachineryVendorResponse machineryVendorResponse = MachineryVendorResponse.builder()
                    .shopName((String) row[0])
                    .completeAddress((String) row[1])
                    .district((String) row[2])
                    .state((String) row[3])
                    .country((String) row[4])
                    .postalCode((Integer) row[5])
                    .userName((String) row[6])
                    .userPhone((String) row[7])
                    .userEmail((String) row[8])
                    .profileImageUrl((String) row[9])
                    .experience((String) row[10])
                    .deliveredProjects((String) row[11])
                    .ongoingProjects((String) row[12])
                    .machineryName(machineryName) // Add the service name to the response
                    .rating(new Random().nextInt(5) + 1)
                    .build();
            // Add the response to the list
            responseList.add(machineryVendorResponse);
        }

        // Return the list of responses
        return responseList;
	}
      

}
