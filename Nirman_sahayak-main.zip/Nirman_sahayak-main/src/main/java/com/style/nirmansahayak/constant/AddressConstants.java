package com.style.nirmansahayak.constant;

public class AddressConstants {
    public static final String COUNTRY = "India";   // Constant for country
    public static final String STATUS_ACTIVE = "Active";  // Constant for status
}
