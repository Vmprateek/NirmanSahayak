package com.style.nirmansahayak.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.service.HomePageService;
import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/api/v1")
@Slf4j
public class HomePageController {

    @Autowired
    private HomePageService homePageService;

    /**
     * Get all home page data.
     * 
     * @return The home page data.
     */
    @GetMapping("/findAllHomePageData")
    public ResponseEntity<?> getHomePageData() {   
        log.info("Method: getHomePageData, Layer: Controller, Request: Fetching all home page data");

        try {
            String homePageData = homePageService.getHomePageData();  
            log.info("Method: getHomePageData, Layer: Controller, Response: {}", homePageData);
            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> homePageJson = objectMapper.readValue(homePageData, Map.class);  // Convert to Map
            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS, "Data fetched successfully", homePageJson);
        } catch (Exception e) {
            log.error("Error occurred while fetching home page data: {}", e.getMessage());
            return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error fetching home page data", null);
        }
    }
}
