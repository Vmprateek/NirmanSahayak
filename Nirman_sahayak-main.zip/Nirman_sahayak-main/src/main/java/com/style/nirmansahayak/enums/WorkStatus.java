package com.style.nirmansahayak.enums;

public enum WorkStatus {
    PENDING,       // Work is created but not yet assigned or started
    ASSIGNED,      // Work is assigned to a laborer, contractor, or team
    IN_PROGRESS,   // Work is currently being worked on
    ON_HOLD,       // Work is temporarily paused
    COMPLETED,     // Work is successfully completed
    CANCELLED      // Work is canceled
}
