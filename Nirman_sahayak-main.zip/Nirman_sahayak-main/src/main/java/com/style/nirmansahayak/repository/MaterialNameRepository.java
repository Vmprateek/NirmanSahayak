package com.style.nirmansahayak.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.style.nirmansahayak.model.MaterialName;

import io.lettuce.core.dynamic.annotation.Param;
import jakarta.transaction.Transactional;

public interface MaterialNameRepository extends JpaRepository<MaterialName,Integer> {

	@Modifying
	@Transactional
	@Query("DELETE FROM MaterialName m WHERE m.materialVendor.materialVendorId = :vendorId")
	void deleteAllByMaterialVendorId(@Param("vendorId") Integer vendorId);
}
