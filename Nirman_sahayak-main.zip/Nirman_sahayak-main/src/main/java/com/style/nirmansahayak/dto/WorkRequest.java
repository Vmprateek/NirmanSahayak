package com.style.nirmansahayak.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkRequest {
    private String name;
    private String typeOfWork;
    private String workDescription;
    private String workAddress;
    private Double quotedPrice;
    private Double latitude;
    private Double longitude;
    private Integer noOfLabours;
    private Integer userId;
    
}
