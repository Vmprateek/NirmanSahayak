package com.style.nirmansahayak.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import com.fasterxml.jackson.databind.JsonNode;
import com.style.nirmansahayak.dto.PostalDetails;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class PostalService {

    private WebClient webClient;

    public PostalService(WebClient.Builder webClientBuilder) {
        this.webClient = webClientBuilder.baseUrl("https://api.postalpincode.in").build();
    }

    public Mono<PostalDetails> getPostalDetails(Integer pincode) {
        return webClient.get()
                .uri("/pincode/{pincode}", pincode)
                .retrieve()
                .bodyToMono(JsonNode.class) // Map response to JsonNode
                .doOnNext(response -> log.info("Response received for pincode {}: {}", pincode, response)) // Log the full response
                .map(response -> {
                    // Log the response for debugging
                    log.info("Postal details API response: {}", response);

                    // Check if the response contains PostOffice data
                    JsonNode postOfficeArray = response.get(0).get("PostOffice");
                    
                    if (postOfficeArray != null && postOfficeArray.isArray() && postOfficeArray.size() > 0) {
                        // Iterate over the post offices and select the first one with Delivery status "Delivery"
                        for (JsonNode postOffice : postOfficeArray) {
                            String deliveryStatus = postOffice.path("DeliveryStatus").asText();
                            if ("Delivery".equals(deliveryStatus)) {
                                String state = postOffice.path("State").asText();  // Extract state
                                String district = postOffice.path("District").asText();  // Extract district
                                log.info("Post office found: State: {}, District: {}", state, district);
                                return new PostalDetails(state, district);
                            }
                        }
                    } else {
                        log.warn("No PostOffice data found for pincode {}", pincode);
                    }

                    // Fallback if no delivery post office is found or data is missing
                    return new PostalDetails("Unknown", "Unknown");
                });
    }
}
