package com.style.nirmansahayak.enums;

public enum MaterialStatus {
	PENDING,       
    ASSIGNED,      
    IN_PROGRESS,   
    ON_HOLD,       
    COMPLETED,
    CANCELLED ,
    ACTIVE
}
