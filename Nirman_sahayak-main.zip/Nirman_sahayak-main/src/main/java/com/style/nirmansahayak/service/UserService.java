package com.style.nirmansahayak.service;

import com.style.nirmansahayak.exception.ResourceNotFoundException;
import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.repository.UserRepository;

import jakarta.persistence.QueryTimeoutException;
import lombok.extern.slf4j.Slf4j;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.BadSqlGrammarException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    // Fetch user by ID
    public User getUserById(Integer userId) {
        log.info("Method: getUserById, Layer: Service, Request: {}", userId);
        
        Optional<User> user = userRepository.findById(userId);
        
        if (user.isPresent()) {
            log.info("User found with ID: {}. User details: {}", userId, user.get());
            return user.get();
        } else {
            log.warn("User not found with ID: {}", userId);
            return null;  // OR throw a custom exception
        }
    }


    // Save a new User
    @Transactional
    public User saveUser(User user) {
        try {
            log.info("Method: saveUser, Layer: Service, Request: {}", user);

            // Additional validation (optional)
            // Save user to the database
            User savedUser = userRepository.save(user);
            log.info("User successfully created with ID: {}", savedUser.getUserId());
            return savedUser;

        } catch (DataIntegrityViolationException e) {
            // Handles unique constraint, foreign key, and other integrity issues
            log.error("Data integrity violation: {}", e.getMessage());
            throw new RuntimeException("Database integrity constraint violation occurred.", e);

        } catch (BadSqlGrammarException e) {
            // Handles SQL syntax errors
            log.error("SQL syntax error: {}", e.getMessage());
            throw new RuntimeException("There was a syntax error in the SQL query.", e);

        } catch (CannotAcquireLockException e) {
            // Handles lock-related issues
            log.error("Database lock acquisition issue: {}", e.getMessage());
            throw new RuntimeException("Database lock acquisition failed. Please try again.", e);

        } catch (QueryTimeoutException e) {
            // Handles query timeout errors
            log.error("Query timeout: {}", e.getMessage());
            throw new RuntimeException("Database query timed out. Please try again later.", e);

        } catch (DataAccessResourceFailureException e) {
            // Handles issues connecting to the database
            log.error("Database access resource failure: {}", e.getMessage());
            throw new RuntimeException("Failed to access the database. Please check the connection.", e);

        } catch (Exception e) {
            // Generic fallback for any unexpected errors
            log.error("Unexpected error while saving user: {}", e.getMessage());
            throw new RuntimeException("An unexpected error occurred.", e);
        }
    }


    // Update an existing User
    @Transactional
    public User updateUser(User user) {
        log.info("Method: updateUser, Layer: Service, Request: {}", user);
        
        // Check if the user exists by ID
        if (userRepository.existsById(user.getUserId())) {
            
            // Fetch the existing user
            User existingUser = userRepository.findById(user.getUserId()).orElse(null);
            
            if (existingUser != null) {
                // Update the user fields if they are provided
                existingUser.setUserName(user.getUserName() != null ? user.getUserName() : existingUser.getUserName());
                existingUser.setUserPhone(user.getUserPhone() != null ? user.getUserPhone() : existingUser.getUserPhone());
                existingUser.setUserEmail(user.getUserEmail() != null ? user.getUserEmail() : existingUser.getUserEmail());
                existingUser.setProfileImageUrl(user.getProfileImageUrl() != null ? user.getProfileImageUrl() : existingUser.getProfileImageUrl());
                existingUser.setExperience(user.getExperience() != null ? user.getExperience() : existingUser.getExperience());
                existingUser.setDeliveredProjects(user.getDeliveredProjects() != null ? user.getDeliveredProjects() : existingUser.getDeliveredProjects());
                existingUser.setOngoingProjects(user.getOngoingProjects() != null ? user.getOngoingProjects() : existingUser.getOngoingProjects());
                existingUser.setCreatedAt(user.getCreatedAt() != null ? user.getCreatedAt() : existingUser.getCreatedAt());
                existingUser.setStatus(user.getStatus() != null ? user.getStatus() : existingUser.getStatus());
                
                // Save the updated user
                User updatedUser = userRepository.save(existingUser);               
                log.info("User updated successfully with ID: {}", updatedUser.getUserId());
                return updatedUser;
            } else {
                log.warn("User not found with ID: {}", user.getUserId());
                return null;  // Return null if user does not exist
            }
        } else {
            log.warn("User not found with ID: {}", user.getUserId());
            return null;  // Return null if user does not exist
        }
    }


    // Delete a User
    @Transactional
    public void deleteUser(Integer userId) {
        log.info("Method: deleteUser, Layer: Service, Request: {}", userId);
        if (userRepository.existsById(userId)) {
            userRepository.deleteById(userId);
            log.info("User successfully deleted with ID: {}", userId);
        } else {
            log.warn("User not found for deletion with ID: {}", userId);
        }
    }

    public Optional<User> findUserByPhone(String phoneNumber) {
        log.info("Method: findUserByPhone, Layer: Service, Request: {}", phoneNumber);
        Optional<User> user = userRepository.findByUserPhone(phoneNumber);
        if (user.isPresent()) {
            log.info("User found with phone number: {}", phoneNumber);
        } else {
            log.warn("User not found with phone number: {}", phoneNumber);
        }
        return user;
    }

    public void updateUserProfileImage(Integer userId, String imageUrl) {
        User user = userRepository.findById(userId).orElse(null);      
        user.setProfileImageUrl(imageUrl);  // Assuming your User model has a 'profileImageUrl' field
        userRepository.save(user);  // Save the updated user to the database
    }
    
    
    
//    public User getUserByIdWithActivities(Integer userId) {
//        log.info("Method: getUserByIdWithActivities, Layer: Service, Request: " + userId);
//        
//        Optional<User> user = userRepository.findUserByIdWithActivities(userId);
//        
//        if (user.isPresent()) {
//            log.info("User found with ID: " + userId + ". User details: " + user.get());
//            return user.get();
//        } else {
//            log.error("User not found with ID: " + userId);
//            return null;
//        }
//    }
}
