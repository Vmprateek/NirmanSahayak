package com.style.nirmansahayak.config;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(prefix = "service")
public class ServiceProperties { 
    private List<String> machinery;  
	private List<String> service; 
	private List<String> material;  	
    private List<String> route;
}
