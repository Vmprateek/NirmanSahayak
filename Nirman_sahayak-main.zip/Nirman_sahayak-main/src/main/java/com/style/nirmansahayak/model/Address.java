package com.style.nirmansahayak.model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.style.nirmansahayak.enums.AddressType;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "address")
public class Address {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "address_sequence")
    @SequenceGenerator(name = "address_sequence", sequenceName = "address_sequence", initialValue = 1, allocationSize = 1)
    private Integer addressId;
    private String houseFlatFloorNumber;
    private String subLocality;
    private String locality;
    private String subAdministrativeArea;
    private String administrativeArea;
    private String country;
    private Integer postalCode;
    
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonIgnore
    private User user;
}
