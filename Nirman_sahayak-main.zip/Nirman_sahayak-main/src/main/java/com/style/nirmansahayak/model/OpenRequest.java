package com.style.nirmansahayak.model;

import lombok.*;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class OpenRequest {

	@Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "your_sequence_add")
    @SequenceGenerator(name = "your_sequence_add", sequenceName = "your_sequence", initialValue = 1, allocationSize = 1)
    private Integer openRequestId;
	private String name;
	private String category;
	private String subCategory;
	private String description ;	
	private String phone;
    private String completeAddress;
    private String district;
    private String state;  
    private String country;
    private Integer postalCode;
    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDateTime postedDateTime;
    private String status;
    private String type;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonBackReference
    private User user;
} 
