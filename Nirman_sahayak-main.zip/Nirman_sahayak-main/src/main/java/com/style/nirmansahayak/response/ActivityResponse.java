package com.style.nirmansahayak.response;

import java.util.List;
import java.util.Map;

public class ActivityResponse {

    private List<Map<String, Object>> machinery;
    private List<Map<String, Object>> material;
    private List<Map<String, Object>> work;
    private List<Map<String, Object>> openRequests;

    public ActivityResponse(List<Map<String, Object>> machinery, List<Map<String, Object>> material,
                            List<Map<String, Object>> work, List<Map<String, Object>> openRequests) {
        this.machinery = machinery;
        this.material = material;
        this.work = work;
        this.openRequests = openRequests;
    }

    // Getters and Setters
    public List<Map<String, Object>> getMachinery() {
        return machinery;
    }

    public void setMachinery(List<Map<String, Object>> machinery) {
        this.machinery = machinery;
    }

    public List<Map<String, Object>> getMaterial() {
        return material;
    }

    public void setMaterial(List<Map<String, Object>> material) {
        this.material = material;
    }

    public List<Map<String, Object>> getWork() {
        return work;
    }

    public void setWork(List<Map<String, Object>> work) {
        this.work = work;
    }

    public List<Map<String, Object>> getOpenRequests() {
        return openRequests;
    }

    public void setOpenRequests(List<Map<String, Object>> openRequests) {
        this.openRequests = openRequests;
    }
}
