package com.style.nirmansahayak.constant;

public class Constant {
	
	
	public static final String INITIAL_REQUEST   = "Initial Request";
	public static final String REQUEST   = "Request Value";
	
    public static final String FINAL_RESPONSE  = "Final Response";
    public static final String RESPONSE  = "Response";
    public static final String SUCCESS_EXCEPTION_DESC    = "success";

}
