package com.style.nirmansahayak.response;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.style.nirmansahayak.enums.ResponseCodeEnum;

public class ResponseBuilder {

    // Static method to build uniform responses
    public static <T> ResponseEntity<NirmanSahayakResponse<T>> buildResponse(
            HttpStatus status, 
            ResponseCodeEnum responseCodeEnum, 
            String message, 
            T data) {

        NirmanSahayakResponse<T> nirmanSahayakResponse = NirmanSahayakResponse.<T>builder()               
                .code(responseCodeEnum.getCode())  
                .status(message)   
                .desc(status.getReasonPhrase())   
                .data(data)
                .build();

        return ResponseEntity.status(status).body(nirmanSahayakResponse);
    }
}
