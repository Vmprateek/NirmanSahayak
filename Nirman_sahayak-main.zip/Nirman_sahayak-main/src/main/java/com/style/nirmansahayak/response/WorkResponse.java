package com.style.nirmansahayak.response;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
@AllArgsConstructor
public class WorkResponse {
	
	    private Integer workId;
	    private String name;
	    private String typeOfWork;
	    private String workDescription;
	    private String  completeAddress;
	    private Integer noOfLabours;
	    private Double  quotedPrice;
	    @JsonFormat(pattern = "dd-MM-yyyy")
	    private LocalDateTime postedDateTime;   
	    private String  district;
	    private String  state;  
	    private String  country;
	    private Integer postalCode;  
	    private String  status; 
	    private Integer userId;
	    private String userName;
	    private String userPhone;
	    private String userEmail;
	    private List<String> workImageUrl;	
	    
}
