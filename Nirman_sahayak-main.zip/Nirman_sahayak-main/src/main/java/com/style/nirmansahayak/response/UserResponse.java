package com.style.nirmansahayak.response;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserResponse {
    private Integer id;
    private String name;
    private String phone;
    private String email;
    private String createdAt;  // Formatted createdAt date
    private String status;
    private String message;
}
