

package com.style.nirmansahayak.model;
import java.util.List;

import org.hibernate.annotations.ManyToAny;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class MaterialVendor {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "addition_info_sequence")
    @SequenceGenerator(name = "addition_info_sequence", sequenceName = "addition_info_sequence", initialValue = 1, allocationSize = 1)
    private Integer materialVendorId;    
    private String  shopName;  
    private String  completeAddress;
    private String  district;
    private String  state;  
    private String  country;
    private Integer postalCode;   
    private String  status;
    
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "material_vendor_id")
    private List<MaterialName> materialNames;
    
    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonBackReference
    private User user;
}
