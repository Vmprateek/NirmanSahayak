package com.style.nirmansahayak.dto;

import lombok.Data;

@Data
public class AddressResponseDTO {
    private Integer addressId;
    private String address1;
    private String address2;
    private String city;
    private Integer pin;
    private Integer userId;

    public AddressResponseDTO(Integer addressId, AddressRequestDTO request) {
        this.addressId = addressId;
        this.address1 = request.getAddress1();
        this.address2 = request.getAddress2();
        this.city = request.getCity();
        this.pin = request.getPin();
        this.userId = request.getUserId();
    }

    // Getters and Setters
}
