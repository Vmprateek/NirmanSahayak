//package com.style.nirmansahayak.repository;
//import java.util.List;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;
//
//import com.style.nirmansahayak.model.Address;
//
//public interface AddressRepository extends JpaRepository<Address, Integer> {
//
//	Address findByPin(int pin);
//	
//	@Query(value = "SELECT * FROM address WHERE city LIKE CONCAT('%', :searchTerm, '%') OR CAST(pin AS TEXT) LIKE CONCAT('%', :searchTerm, '%')", 
//		       nativeQuery = true)
//		List<Address> findByCityLike(@Param("searchTerm") String searchTerm);
//}
