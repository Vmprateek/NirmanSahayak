package com.style.nirmansahayak.dto;

import lombok.Data;

@Data
public class MachineryRequest {
    private String shopName;
    private String shopAddress;
    private String typeOfMachinery;
    private String machineryDescription;
    private Double quotedPrice;
    private Double latitude;
    private Double longitude;
    private Integer userId;
}
