package com.style.nirmansahayak.controller;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.style.nirmansahayak.dto.PostalDetails;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.model.OpenRequest;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.service.OpenRequestService;
import com.style.nirmansahayak.service.PostalService;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;
@Slf4j
@RestController
@RequestMapping("/api/v1")
public class OpenRequestController {

    @Autowired
    private OpenRequestService openRequestService;
    @Autowired
    PostalService postalService;

    // Save OpenRequest
    @PostMapping("/saveOpenRequest")
    public ResponseEntity<OpenRequest> saveOpenRequest(@RequestBody OpenRequest openRequest) {
    	
    	Mono<PostalDetails> data = postalService.getPostalDetails(openRequest.getPostalCode());
    	PostalDetails postalDetails = data.block();

    	// Set the district and state values in the serviceProviderInfo object
    	if (postalDetails != null) {
    		openRequest.setDistrict(postalDetails.getDistrict());
    		openRequest.setState(postalDetails.getState());
    	} else {
    		openRequest.setDistrict("Unknown");
    		openRequest.setState("Unknown");
    	}

    	openRequest.setCountry("India");
    	openRequest.setPostedDateTime(LocalDateTime.now());
    	openRequest.setStatus("ACTIVE");
        OpenRequest savedOpenRequest = openRequestService.saveOpenRequest(openRequest);
        return ResponseEntity.ok(savedOpenRequest);
    }
    
    
    @GetMapping("/findAllOpenRequestByLocation")
    public ResponseEntity<?> getOpenRequestsByLocation(@RequestParam(required = false) Integer postalCode) {
        List<OpenRequest> openRequests = openRequestService.getOpenRequestsByLocation(postalCode);

        if (openRequests.isEmpty()) {
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.NO_CONTENT,
                    "No open requests found for the given postal code.",
                    Collections.emptyList()
            );
        }

        return ResponseBuilder.buildResponse(
                HttpStatus.OK,
                ResponseCodeEnum.SUCCESS,
                "Open requests fetched successfully.",
                openRequests
        );
    }
    
    
    @DeleteMapping("/deleteOpenRequest/{id}")
    public ResponseEntity<?> deleteOpenRequest(@PathVariable Integer id) {
        log.info("Method: deleteOpenRequest, Layer: Controller, Request: Deleting OpenRequest with ID: {}", id);

        boolean isDeleted = openRequestService.deleteOpenRequest(id);
        if (isDeleted) {
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "OpenRequest deleted successfully",
                    null
            );
        } else {
            return ResponseBuilder.buildResponse(
                    HttpStatus.NOT_FOUND,
                    ResponseCodeEnum.NOT_FOUND,
                    "OpenRequest not found with ID: " + id,
                    null
            );
        }
    }


}
