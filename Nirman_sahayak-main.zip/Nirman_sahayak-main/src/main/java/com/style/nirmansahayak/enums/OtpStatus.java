package com.style.nirmansahayak.enums;

public enum OtpStatus {
    DELIVERED,       // OTP delivered successfully
    FAILED,          // OTP delivery failed
    USER_EXISTING,   // User exists
    USER_NOT_EXISTING; // User does not exist
}
