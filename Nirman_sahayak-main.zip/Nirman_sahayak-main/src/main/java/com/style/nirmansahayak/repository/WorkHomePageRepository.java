package com.style.nirmansahayak.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.style.nirmansahayak.entity.HomePage;
import com.style.nirmansahayak.model.Work;

import org.springframework.data.jpa.repository.JpaRepository;
public interface WorkHomePageRepository extends JpaRepository<HomePage, Integer> {

	
}
