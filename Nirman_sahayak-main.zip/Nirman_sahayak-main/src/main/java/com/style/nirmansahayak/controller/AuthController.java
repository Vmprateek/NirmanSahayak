package com.style.nirmansahayak.controller;

import java.time.LocalDateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.style.nirmansahayak.dto.OtpRequest;
import com.style.nirmansahayak.dto.OtpResponseDto;
import com.style.nirmansahayak.dto.OtpVerificationRequest;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.enums.UserStatus;
import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.response.VerifyOtpResponse;
import com.style.nirmansahayak.service.OtpService;
import com.style.nirmansahayak.service.UserService;
import com.style.nirmansahayak.utils.JwtUtil;
import com.style.nirmansahayak.response.ResponseBuilder;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
@Slf4j
@RestController
@RequestMapping("/api/v1")
public class AuthController {

    private final OtpService otpService;

    @Autowired
    private UserService userService;

    @Autowired
    JwtUtil jwtUtil;

    public AuthController(OtpService otpService) {
        this.otpService = otpService;
    }

    @PostMapping("/sendOtp")
    public ResponseEntity<?> requestOtp(@RequestBody @Valid OtpRequest request) {
        try {
            log.info("Received OTP request for phone number: {}", request.getUserPhone());
            OtpResponseDto responseDto = otpService.generateOtp(request.getUserPhone());
            log.info("OTP generated and sent to phone number: {}", request.getUserPhone());
            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.CREATED, "OTP sent successfully", responseDto);
        } catch (Exception e) {
            log.error("Error while sending OTP to phone number: {}", request.getUserPhone(), e);
            return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error occurred while sending OTP.", null);
        }
    }

    @PostMapping("/verifyOtp")
    public ResponseEntity<?> verifyOtp(@RequestBody @Valid OtpVerificationRequest request) {
        try {
            log.info("Received OTP verification request for phone number: {}", request.getUserPhone());

            boolean isValid = otpService.validateOtp(request.getUserPhone(), request.getOtp());

            if (isValid) {
                log.info("OTP validated successfully for phone number: {}", request.getUserPhone());
                String accessToken = jwtUtil.generateToken(request.getUserPhone());
                User userData = handleUserCreationOrRetrieval(request);
                VerifyOtpResponse verifyOtpResponse = buildVerifyOtpResponse(userData, accessToken);

                log.info("OTP verification successful for phone number: {}. User authenticated and access token generated.", request.getUserPhone());
                return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.CREATED, "OTP verified successfully", verifyOtpResponse);
            } else {
                log.warn("Invalid OTP entered for phone number: {}", request.getUserPhone());
                return ResponseBuilder.buildResponse(HttpStatus.UNAUTHORIZED, ResponseCodeEnum.UNAUTHORIZED, "Invalid or expired OTP", null);
            }
        } catch (Exception e) {
            log.error("Error during OTP verification for phone number: {}", request.getUserPhone(), e);
            return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error occurred during OTP verification.", null);
        }
    }

    // Method to handle user creation or retrieval
    private User handleUserCreationOrRetrieval(OtpVerificationRequest request) {
        User userData = null;
        if (request.getUserStatus() == UserStatus.USER_NOT_EXISTING) {
            // Create new user if not existing
            log.info("Creating new user for phone number: {}", request.getUserPhone());
            User user = new User();
            user.setUserName(request.getUserName());
            user.setUserPhone(request.getUserPhone());
            user.setStatus("ACTIVE");
            user.setCreatedAt(LocalDateTime.now().withNano(0));
            userData = userService.saveUser(user);
            log.info("New user created with ID: {}", userData.getUserId());
        } else {
            // Handle case when user already exists
            userData = userService.findUserByPhone(request.getUserPhone()).orElse(null);
            if (userData != null) {
                log.info("Existing user found with phone number: {}", request.getUserPhone());
            } else {
                log.warn("User with phone number {} not found in database.", request.getUserPhone());
            }
        }
        return userData;
    }

    // Method to build the response for OTP verification
    private VerifyOtpResponse buildVerifyOtpResponse(User userData, String accessToken) {
        log.debug("Building OTP verification response for user ID: {}", userData.getUserId());
        return VerifyOtpResponse.builder()
                .userId(userData.getUserId())
                .userName(userData.getUserName())
                .userPhone(userData.getUserPhone())
                .userEmail(userData.getUserEmail())
                .profileImageUrl(userData.getProfileImageUrl())
                .createdAt(userData.getCreatedAt())
                .status(userData.getStatus())
                .accessToken(accessToken)
                .build();
    }
}
