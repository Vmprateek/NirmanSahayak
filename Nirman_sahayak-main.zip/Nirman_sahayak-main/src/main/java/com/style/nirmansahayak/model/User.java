package com.style.nirmansahayak.model;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
@ToString
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "all_user") // Maps to the "all_user" table
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user_sequence")
    @SequenceGenerator(name = "user_sequence", sequenceName = "user_sequence", initialValue = 1, allocationSize = 1)
    private Integer userId;
    private String userName;
    private String userPhone;
    private String userEmail;
    private String profileImageUrl;
    private String experience;
    private String deliveredProjects;
    private String ongoingProjects;
    @JsonFormat(pattern = "dd-MM-yyyy")
    private LocalDateTime createdAt;
    private String currentService;
    private String status;
    

 
    
    @JsonInclude(JsonInclude.Include.NON_NULL) 
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private ServiceProvider serviceProvider;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)  
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private MaterialVendor materialVendor;
     
    @JsonInclude(JsonInclude.Include.NON_NULL) 
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private MachineryVendor machineryVendor;
    
    
    
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Work> works;

   
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<OpenRequest> openRequests;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Material> materials;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Machinery> machineries;
}
