package com.style.nirmansahayak.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.style.nirmansahayak.model.ServiceProvider;

public interface ServiceProviderRepository extends JpaRepository<ServiceProvider, Integer> {

	@Query(value = """
			(
			    SELECT sp.shop_name,
			        sp.complete_address,
			        sp.district, sp.spstate,
			        sp.country,
			        sp.postal_code,
			        u.user_name,
			        u.user_phone,
			        u.user_email,
			        u.profile_image_url,
			        u.experience,
			        u.delivered_projects,
			        u.ongoing_projects,
			        cf.rating
			    FROM service_provider sp
			    JOIN service_name sn ON sp.service_provider_id = sn.service_provider_id
			    JOIN all_user u ON sp.user_id = u.user_id
			    LEFT JOIN customer_feedback cf ON sp.service_provider_id = cf.service_provider_id
			    WHERE sn.service_name = :serviceName
			    AND sp.postal_code = :postalCode
			    LIMIT 5
			)
			UNION
			(
			    SELECT sp.shop_name,
			        sp.complete_address,
			        sp.district, sp.spstate,
			        sp.country, sp.postal_code,
			        u.user_name, u.user_phone,
			        u.user_email,
			        u.profile_image_url,
			        u.experience,
			        u.delivered_projects,
			        u.ongoing_projects,
			        cf.rating
			    FROM service_provider sp
			    JOIN service_name sn ON sp.service_provider_id = sn.service_provider_id
			    JOIN all_user u ON sp.user_id = u.user_id
			    LEFT JOIN customer_feedback cf ON sp.service_provider_id = cf.service_provider_id
			    WHERE sn.service_name = :serviceName
			    AND sp.district = (SELECT district FROM service_provider WHERE postal_code = :postalCode LIMIT 1)
			    LIMIT 15
			)
			""", nativeQuery = true)
	List<Object[]> findByServiceNameAndPostal(@Param("serviceName") String serviceName,
			@Param("postalCode") Integer postalCode);

	@Query(value = "SELECT * FROM service_provider WHERE user_id = :userId LIMIT 1", nativeQuery = true)
	Optional<ServiceProvider> findByUserId(@Param("userId") Integer userId);

}
