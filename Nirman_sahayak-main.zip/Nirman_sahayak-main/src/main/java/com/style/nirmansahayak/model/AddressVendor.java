package com.style.nirmansahayak.model;

import lombok.Data;

@Data
public class AddressVendor {

    private String name;
    private String branchType;
    private String deliveryStatus;
    private String circle;
    private String district;
    private String division;
    private String region;
    private String block;
    private String state;
    private String country;
    private String pincode;
}
