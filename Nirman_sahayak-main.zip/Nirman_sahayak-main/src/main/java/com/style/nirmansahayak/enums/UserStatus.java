package com.style.nirmansahayak.enums;

public enum UserStatus {
    PENDING,       // User is pending activation or approval
    IN_PROGRESS,   // User is currently being processed or active in a task
    ACTIVE,        // User is active
    INACTIVE,      // User is inactive
    SUSPENDED,     // User is suspended
    DELETED  ,
    USER_EXISTING,   // User exists
    USER_NOT_EXISTING; //
    // User is deleted
}
