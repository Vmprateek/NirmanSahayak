package com.style.nirmansahayak.service;

import com.style.nirmansahayak.dto.PostalDetails;
import com.style.nirmansahayak.dto.ServiceProviderDTO;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.model.ServiceProvider;
import com.style.nirmansahayak.repository.ServiceProviderRepository;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.response.ServiceProviderResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

@Service
@Slf4j
public class ServiceProviderService {

	@Autowired
	private ServiceProviderRepository serviceProviderInfoRepository;

	@Autowired
	PostalService postalService;

	/**
	 * Save a service provider.
	 *
	 * @param serviceProviderInfo The service provider object to save.
	 * @return The saved ServiceProvider object.
	 */
	public ServiceProvider saveServiceProvider(ServiceProvider serviceProviderInfo) {
		long startTime = System.currentTimeMillis();
		log.info("Method: saveServiceProvider, Layer: Service, Request: Saving service provider: {}",
				serviceProviderInfo);
		try {
		
			Mono<PostalDetails> data = postalService.getPostalDetails(serviceProviderInfo.getPostalCode());
			PostalDetails postalDetails = data.block();

			// Set the district and state values in the serviceProviderInfo object
			if (postalDetails != null) {
				serviceProviderInfo.setDistrict(postalDetails.getDistrict());
				serviceProviderInfo.setSpstate(postalDetails.getState());
			} else {
				serviceProviderInfo.setDistrict("Unknown");
				serviceProviderInfo.setSpstate("Unknown");
			}

			serviceProviderInfo.setCountry("India");
			// serviceProviderInfo.setStatus("ACTIVE");
			ServiceProvider savedProvider = serviceProviderInfoRepository.save(serviceProviderInfo);
			log.info("Method: saveServiceProvider, Layer: Service, Successfully saved service provider: {}",
					savedProvider);
			return savedProvider;

		} catch (DataIntegrityViolationException e) {
			log.error("Database constraint violation: {}", e.getMessage(), e);
			throw new RuntimeException("Duplicate user ID found. A service provider already exists for this user.");
		} catch (Exception e) {
			log.error("Method: saveServiceProvider, Layer: Service, Error saving service provider: {}",
					serviceProviderInfo, e);
			throw new RuntimeException("Failed to save service provider due to internal error", e); // Providing a
																									// meaningful
																									// exception message
		} finally {
			long endTime = System.currentTimeMillis();
			log.info("Method: saveServiceProvider, Layer: Service, Execution Time: {} ms", (endTime - startTime));
		}
	}

	/**
	 * 
	 * public List<ServiceProvider> findByServiceNameAndLocation(String serviceName,
	 * String locality, String subLocality) { return
	 * serviceProviderRepository.findByServiceNameAndLocation(serviceName, locality,
	 * subLocality); } Find service providers by service name.
	 *
	 * @param serviceName The name of the service.
	 * @param postalCode
	 * @return List of ServiceProvider objects.
	 */
	public List<ServiceProviderResponse> findByServiceNameAndLocation(String serviceName, Integer postalCode,
			String district) {
		// Fetch data from the repository (or query)
		List<Object[]> data = serviceProviderInfoRepository.findByServiceNameAndPostal(serviceName, postalCode);

		// Create a list to store the response
		List<ServiceProviderResponse> responseList = new ArrayList<>();

		// Loop through each result from the query

		for (Object[] row : data) {
			// Create a new ServiceProviderResponse for each row
			ServiceProviderResponse serviceProviderResponse = ServiceProviderResponse.builder()
					.shopName((String) row[0]).completeAddress((String) row[1]).district((String) row[2])
					.state((String) row[3]).country((String) row[4]).postalCode((Integer) row[5])
					.userName((String) row[6]).userPhone((String) row[7]).userEmail((String) row[8])
					.profileImageUrl((String) row[9]).experience((String) row[10]).deliveredProjects((String) row[11])
					.ongoingProjects((String) row[12]).serviceName(serviceName) // Add the service name to the response
					.rating((Integer) row[13]).build();
			// Add the response to the list
			responseList.add(serviceProviderResponse);
		}

		// Return the list of responses
		return responseList;
	}

}
