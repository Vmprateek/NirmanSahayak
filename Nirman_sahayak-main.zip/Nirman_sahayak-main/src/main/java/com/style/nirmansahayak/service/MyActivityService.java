package com.style.nirmansahayak.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.style.nirmansahayak.response.ActivityResponse;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class MyActivityService {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public ActivityResponse getUserActivities(Long userId) {
        log.info("Fetching activities for user with ID: {}", userId);
        
        // SQL query for optimized fetching of user data
        String query = 
            "SELECT * " +
            "FROM machinery m " +
            "LEFT JOIN material mt ON m.user_id = mt.user_id " +
            "LEFT JOIN work w ON m.user_id = w.user_id " +
            "LEFT JOIN open_request orr ON m.user_id = orr.user_id " +
            "WHERE m.user_id = ?";
        
        try {
            // Execute the optimized query
            log.debug("Executing query to fetch user activities: {}", query);
            List<Map<String, Object>> result = jdbcTemplate.queryForList(query, userId);
            log.info("Fetched {} rows for user activities", result.size());

            // Process and split the result into respective categories
            List<Map<String, Object>> machinery = extractFromResult(result, "machinery");
            List<Map<String, Object>> material = extractFromResult(result, "material");
            List<Map<String, Object>> work = extractFromResult(result, "work");
            List<Map<String, Object>> openRequests = extractFromResult(result, "open_request");

            // Log successful extraction
            log.debug("Extracted {} rows for machinery, {} rows for material, {} rows for work, and {} rows for open requests",
                      machinery.size(), material.size(), work.size(), openRequests.size());

            // Return as response
            return new ActivityResponse(machinery, material, work, openRequests);

        } catch (Exception e) {
            // Log and handle any potential exceptions
            log.error("Error occurred while fetching user activities for userId: {}", userId, e);
            throw new RuntimeException("Failed to fetch user activities", e); // Optionally, return a custom response for failure
        }
    }

    // Helper method to extract specific data from the result
    private List<Map<String, Object>> extractFromResult(List<Map<String, Object>> result, String category) {
        try {
            log.debug("Extracting data for category: {}", category);
            List<Map<String, Object>> filteredResult = result.stream()
                                                             .filter(row -> row.get("category").equals(category))
                                                             .collect(Collectors.toList());
            log.info("Extracted {} rows for category: {}", filteredResult.size(), category);
            return filteredResult;
        } catch (Exception e) {
            log.error("Error occurred while extracting data for category: {}", category, e);
            throw new RuntimeException("Failed to extract data for category: " + category, e);
        }
    }
}
