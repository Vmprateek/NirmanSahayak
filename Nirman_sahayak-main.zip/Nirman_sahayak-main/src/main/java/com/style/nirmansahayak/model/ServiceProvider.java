package com.style.nirmansahayak.model;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.style.nirmansahayak.dto.ServiceNameDTO;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Transient;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
public class ServiceProvider {
	
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "your_sequence_add")
    @SequenceGenerator(name = "your_sequence_add", sequenceName = "your_sequence", initialValue = 1, allocationSize = 1)
    private Integer serviceProviderId;
    private String  shopName;  
    private String  completeAddress;
    private String  district;
    private String  spstate;  
    private String  country;
    private Integer postalCode; 
    private String  spStatus;
    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JoinColumn(name = "service_provider_id")
    private List<ServiceName>  serviceNames; 
    
    @OneToOne(fetch = FetchType.EAGER) 
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonBackReference
   // @JsonManagedReference
    private User user;
}
 