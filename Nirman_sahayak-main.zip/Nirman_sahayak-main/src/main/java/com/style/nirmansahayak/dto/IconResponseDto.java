package com.style.nirmansahayak.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class IconResponseDto {
    private Long iconId;
    private String iconName;
    private String fileType;
    private String fileSize;
    private String downloadUrl;
    private String uploadTime;
}
