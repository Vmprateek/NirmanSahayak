package com.style.nirmansahayak.enums;

public enum ResponseCodeEnum {

	SUCCESS("200", "NirmanService", "Operation successful"),
	CREATED("201", "NirmanService", "Resource created successfully"),
	NO_CONTENT("204", "NirmanService", "No content available"), // ✅ Added 204
	BAD_REQUEST("400", "NirmanService", "Invalid request"),
	NOT_FOUND("404", "NirmanService", "Resource not found"),
	INTERNAL_SERVER_ERROR("500", "NirmanService", "Internal server error"),
	UNAUTHORIZED("401", "NirmanService", "Unauthorized access"),
	FORBIDDEN("403", "NirmanService", "Forbidden access"),
	TOKEN_EXPIRED("498", "NirmanService", "Token has expired"),
	DUPLICATE_ENTRY("409", "NirmanService", "Duplicate entry found");

    private final String code;
    private final String service;
    private final String desc;

    // Constructor
    ResponseCodeEnum(String code, String service, String desc) {
        this.code = code;
        this.service = service;
        this.desc = desc;
    }

    // Getters
    public String getCode() {
        return code;
    }

    public String getService() {
        return service;
    }

    public String getDesc() {
        return desc;
    }
}
