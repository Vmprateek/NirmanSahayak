package com.style.nirmansahayak.service;
import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.RedisConnectionFailureException;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Service;
import com.style.nirmansahayak.dto.OtpResponseDto;
import com.style.nirmansahayak.enums.OtpStatus;
import com.style.nirmansahayak.model.User;
import com.style.nirmansahayak.utils.TwilioSMS;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class OtpService {

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    @Autowired
    private TwilioSMS twilioSMS;

    @Autowired
    private UserService userService;

    private static final int OTP_VALIDITY_MINUTES = 5;
    private final Map<String, String> inMemoryOtpStore = new ConcurrentHashMap<>();

    /**
     * Generate a new OTP for the given phone number.
     *
     * @param phoneNumber Phone number to send the OTP to.
     * @return Generated OTP response.
     */
    public OtpResponseDto generateOtp(String phoneNumber) {
        String otp = generateRandomOtp();
        log.warn("OTP: {}", otp);
        String otpMessage = createOtpMessage(otp);
        OtpStatus userStatus;
        User user = null;

        Optional<User> userOptional = userService.findUserByPhone(phoneNumber);
        if (userOptional.isPresent()) {
            user = userOptional.get();
            log.info("User found: {}", user);
            userStatus = OtpStatus.USER_EXISTING;
        } else {
            userStatus = OtpStatus.USER_NOT_EXISTING;
            log.warn("No user found with phone number: {}", phoneNumber);
        }

        try {
            // Uncomment to enable SMS sending
           // twilioSMS.sendMessage(otpMessage, "+91" + phoneNumber);
            log.info("OTP sent to phone number: {}", phoneNumber);
        } catch (com.twilio.exception.ApiException apiException) {
            // Handle Twilio-specific exceptions
            log.error("Twilio API error occurred while sending OTP to phone number: {}", phoneNumber, apiException);
            throw new RuntimeException("Failed to send OTP due to an issue with the SMS service. Please try again later.", apiException);
        } catch (Exception e) {
            // Handle other exceptions
            log.error("Unexpected error occurred while sending OTP to phone number: {}", phoneNumber, e);
            throw new RuntimeException("Failed to send OTP. Please try again later.", e);
        }

        try {
            storeOtpInRedis(phoneNumber, otp);
        } catch (RedisConnectionFailureException e) {
            log.error("Redis unavailable, storing OTP in memory for phone number: {}", phoneNumber, e);
            inMemoryOtpStore.put(phoneNumber, otp);
        } catch (Exception e) {
            log.error("Error while storing OTP for phone number {}: {}", phoneNumber, e.getMessage(), e);
            throw new RuntimeException("Failed to store OTP. Please try again later.", e);
        }

        return new OtpResponseDto(OtpStatus.DELIVERED, otpMessage, userStatus, user);
    }

    /**
     * Validate the OTP entered by the user.
     *
     * @param phoneNumber Phone number of the user.
     * @param otp OTP entered by the user.
     * @return True if OTP matches, otherwise false.
     */
    public boolean validateOtp(String phoneNumber, String otp) {
        String storedOtp = getOtpFromStore(phoneNumber);
        
        if (storedOtp == null) {
            log.warn("OTP for phone number {} has expired or does not exist.", phoneNumber);
            return false;
        }

        if (storedOtp.equals(otp)) {
            deleteOtpFromStore(phoneNumber);
            log.info("OTP validated successfully for phone number: {}", phoneNumber);
            return true;
        } else {
            log.warn("Invalid OTP entered for phone number: {}", phoneNumber);
            return false;
        }
    }

    private String generateRandomOtp() {
        String otp = String.valueOf(1000 + new Random().nextInt(9000));
        log.debug("Generated OTP: {}", otp);
        return otp;
    }

    private String createOtpMessage(String otp) {
        String message = otp + " is your login OTP for NirmanSahayak App. Do not share it with anyone. NIRMANSAHAYAK";
        log.debug("Created OTP message: {}", message);
        return message;
    }

    private void storeOtpInRedis(String phoneNumber, String otp) {
        try {
            // Check Redis connectivity by performing a test operation
            if (redisTemplate.getConnectionFactory().getConnection().ping() == null) {
                log.warn("Redis connection is unavailable. Falling back to in-memory storage.");
                inMemoryOtpStore.put(phoneNumber, otp);
                return; // Exit the method after storing in memory
            }
            
            // Store OTP in Redis
            ValueOperations<String, String> valueOps = redisTemplate.opsForValue();
            valueOps.set(phoneNumber, otp, Duration.ofMinutes(OTP_VALIDITY_MINUTES));
            log.info("OTP stored in Redis for phone number: {} with expiry of {} minutes", phoneNumber, OTP_VALIDITY_MINUTES);
        } catch (Exception e) {
            // Log error and store OTP in memory as a fallback
            log.error("Error while storing OTP in Redis for phone number: {}. Falling back to in-memory storage. Error: {}", phoneNumber, e.getMessage());
            inMemoryOtpStore.put(phoneNumber, otp);
        }
    }


    private String getOtpFromStore(String phoneNumber) {
        String otp = null;

        // Check if Redis connection is available
        try {
        	
        	System.out.println("Redis Ststus ::"+redisTemplate.getConnectionFactory().getConnection());
        	System.out.println("Redis Ststus Ping ::"+redisTemplate.getConnectionFactory().getConnection().ping());
        	
        	
            if (redisTemplate.getConnectionFactory().getConnection().ping() != null) {
                log.debug("Redis connection is available.");
            }
        } catch (Exception e) {
            log.warn("Redis connection is unavailable while checking for OTP for phone number: {}", phoneNumber);
            // Fallback to in-memory store if Redis is not available
            otp = inMemoryOtpStore.get(phoneNumber);
            log.debug("Retrieved OTP from in-memory store for phone number: {}", phoneNumber);
            return otp;
        }

        try {
            // Attempt to fetch OTP from Redis
            otp = redisTemplate.opsForValue().get(phoneNumber);
            if (otp != null) {
                log.debug("Retrieved OTP from Redis for phone number: {}", phoneNumber);
                return otp;
            }
        } catch (Exception e) {
            log.error("Error fetching OTP from Redis for phone number: {}", phoneNumber, e);
        }

        // If OTP not found in Redis, fall back to in-memory store
        otp = inMemoryOtpStore.get(phoneNumber);
        log.debug("Retrieved OTP from in-memory store for phone number: {}", phoneNumber);
        return otp;
    }



    private void deleteOtpFromStore(String phoneNumber) {
        // Check if Redis connection is available
        try {
            if (redisTemplate.getConnectionFactory().getConnection().ping() != null) {
                log.debug("Redis connection is available.");
            }
        } catch (Exception e) {
            log.warn("Redis connection is unavailable while attempting to delete OTP for phone number: {}", phoneNumber);
            // Fallback to in-memory store if Redis is not available
            inMemoryOtpStore.remove(phoneNumber);
            log.info("OTP removed from in-memory store for phone number: {}", phoneNumber);
            return;  // Skip Redis deletion
        }

        try {
            // Attempt to delete OTP from Redis
            redisTemplate.delete(phoneNumber);
            log.info("OTP deleted from Redis for phone number: {}", phoneNumber);
        } catch (Exception e) {
            log.error("Failed to delete OTP from Redis for phone number: {}", phoneNumber, e);
        }

        // Remove OTP from in-memory store
        inMemoryOtpStore.remove(phoneNumber);
        log.info("OTP removed from in-memory store for phone number: {}", phoneNumber);
    }

}
