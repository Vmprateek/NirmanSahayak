package com.style.nirmansahayak.dto;
import com.style.nirmansahayak.model.User;

import lombok.Data;

@Data
public class MaterialRequest {	
	
    private String typeOfMaterial;
    private String materialDescription;
    private Double quotedPrice;
    private User user;
}
