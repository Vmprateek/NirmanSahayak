package com.style.nirmansahayak.dto;

import com.style.nirmansahayak.enums.OtpStatus;
import com.style.nirmansahayak.model.User;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class OtpResponseDto {
    private OtpStatus status;
    private String message;
    private OtpStatus userStatus;
    private User user;
    
}
