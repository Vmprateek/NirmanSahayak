package com.style.nirmansahayak.response;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NirmanSahayakResponse<T> {

    private String code;
    private String status;
    private String desc;
    private String error;
    private T data;

    public NirmanSahayakResponse() {
    }

    public NirmanSahayakResponse(String code, String desc, String status, String error, T data) {
        this.code = code;   
        this.status = status;
        this.desc = desc;
        this.error = error;
        this.data = data;
    }
}
