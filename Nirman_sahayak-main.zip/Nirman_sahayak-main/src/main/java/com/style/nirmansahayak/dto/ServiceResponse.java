package com.style.nirmansahayak.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
@Data
@AllArgsConstructor
@Setter
@Getter
public class ServiceResponse {
	
	private List<String> machinery;  
	private List<String> service; 
	private List<String> material;  	
    private List<String> route; 
}
