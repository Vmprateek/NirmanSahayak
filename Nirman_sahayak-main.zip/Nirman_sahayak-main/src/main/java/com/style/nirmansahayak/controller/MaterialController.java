package com.style.nirmansahayak.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.style.nirmansahayak.dto.MaterialDTO;
import com.style.nirmansahayak.dto.MaterialRequest;
import com.style.nirmansahayak.model.Material;
import com.style.nirmansahayak.model.Work;
import com.style.nirmansahayak.response.MaterialResponse;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.service.MaterialService;
import com.style.nirmansahayak.service.S3Service;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.style.nirmansahayak.enums.MaterialStatus;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class MaterialController {

	@Autowired
	private MaterialService materialService;

	@Autowired
	private S3Service s3Service;
	ObjectMapper objectMapper = new ObjectMapper();

	@PostMapping("/saveMaterial")
	public ResponseEntity<?> saveMaterial(@RequestPart("material") String materialJson,
			@RequestPart(required = false) List<MultipartFile> files) {
		log.info("Method: saveMaterial, Layer: Controller, Request: Saving material for shop: {}", materialJson);

		try {
			MaterialRequest materialRequest = objectMapper.readValue(materialJson, MaterialRequest.class);
			Material material = Material.builder().typeOfMaterial(materialRequest.getTypeOfMaterial())
					.materialDescription(materialRequest.getMaterialDescription())
					.quotedPrice(materialRequest.getQuotedPrice()).status("ACTIVE").user(materialRequest.getUser())
					.postedDateTime(LocalDateTime.now()).build();
			if (files == null || files.isEmpty()) {
				material.setMaterialImageUrl(Collections.emptyList()); // Set empty string if no files
			} else {
				List<String> imageUrls = files.stream().map(file -> s3Service.uploadFile(file)).toList();
				material.setMaterialImageUrl(imageUrls);
			}
			Material savedMaterial = materialService.saveMaterial(material);
			log.info("Method: saveMaterial, Layer: Controller, Success: Material saved: {}", savedMaterial);

			return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS,
					"Material saved successfully", savedMaterial);
		} catch (Exception e) {
			log.error("Method: saveMaterial, Layer: Controller, Error saving material", e);
			return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR,
					ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error saving material", null);
		}
	}

	@GetMapping("/findAllMaterialByLocation")
	public ResponseEntity<?> searchMaterials(@RequestParam(required = false) Integer postalCode ,@RequestParam(required = false) String typeOfMaterial) {
	    List<MaterialResponse> materials = materialService.getMaterialsByLocation(postalCode ,typeOfMaterial);
	    log.info("Request received - postalCode: {}, typeOfMaterial: {}", postalCode, typeOfMaterial);
	    if (materials.isEmpty()) {
	        return ResponseBuilder.buildResponse(
	                HttpStatus.OK,
	                ResponseCodeEnum.NO_CONTENT,
	                "No materials found for the given postal code.",
	                Collections.emptyList()
	        );
	    }

	    return ResponseBuilder.buildResponse(
	            HttpStatus.OK,
	            ResponseCodeEnum.SUCCESS,
	            "Materials fetched successfully.",
	            materials
	    );
	}


	
	
	@DeleteMapping("/deleteMaterial/{id}")
	public ResponseEntity<?> deleteMaterial(@PathVariable Integer id) {
	    log.info("Method: deleteMaterial, Layer: Controller, Request: Deleting material ID: {}", id);

	    try {
	        boolean isDeleted = materialService.deleteMaterial(id);

	        if (isDeleted) {
	            log.info("Material deleted successfully: {}", id);
	            return ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS,
	                    "Material deleted successfully", null);
	        } else {
	            log.warn("Material with ID {} not found. Deletion failed.", id);
	            return ResponseBuilder.buildResponse(HttpStatus.NOT_FOUND, ResponseCodeEnum.NOT_FOUND,
	                    "Material not found", null);
	        }
	    } catch (Exception e) {
	        log.error("Error deleting material ID: {}", id, e);
	        return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR,
	                ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error deleting material", null);
	    }
	}

	
}
