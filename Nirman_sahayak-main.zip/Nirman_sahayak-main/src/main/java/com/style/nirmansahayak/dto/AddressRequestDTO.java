package com.style.nirmansahayak.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder  // Lombok's builder pattern for flexible object creation
public class AddressRequestDTO {

    // Optional: If addressId needs to be included for updates
    private Integer addressId; // This could be used for updates, but generally omitted for creation.
    private Integer pin;  
    private String address1;   
    private String address2;   
    private String city;
    private Integer userId;

    // No need for custom constructor with @Builder and @Data
}
