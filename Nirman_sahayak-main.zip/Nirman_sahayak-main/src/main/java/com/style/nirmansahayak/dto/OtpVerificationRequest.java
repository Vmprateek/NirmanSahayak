
package com.style.nirmansahayak.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.style.nirmansahayak.enums.UserStatus;
import com.style.nirmansahayak.model.User;

import jakarta.annotation.Nonnull;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OtpVerificationRequest {
    
    @Nonnull
    @Size(min = 10, max = 10, message = "Phone number must be exactly 10 characters.")
    @JsonProperty("userPhone") // Ensure this matches the JSON property name if needed
    private String userPhone;

    @NotNull(message = "OTP cannot be empty or null.")
    @Size(min = 4, max = 4, message = "OTP must be exactly 4 characters.")
    @JsonProperty("otp") // Ensure this matches the JSON property name if needed
    private String otp; 
    @Size(min = 4, max = 400, message = "OTP must be exactly 4 characters.")
    private String userName;
    private UserStatus userStatus;
    
}
