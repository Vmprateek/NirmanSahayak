package com.style.nirmansahayak.model;
import org.hibernate.bytecode.internal.bytebuddy.PrivateAccessorException;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "customer_feedback")
public class CustomerFeedback {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "feedback_sequence")
    @SequenceGenerator(name = "feedback_sequence", sequenceName = "feedback_sequence", initialValue = 1, allocationSize = 1)
    private Long customerFeedbackId;
    private String feedback;
    private Integer rating;  
    private String response; 
    private boolean resolved;
    private Integer userId;
    private Integer serviceProviderId;
}
