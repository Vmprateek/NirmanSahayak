package com.style.nirmansahayak.dto;
import java.time.LocalDateTime;
import java.util.List;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;

@Data
@Builder
public class MaterialDTO {
	
    private Integer materialId;
	private String typeOfMaterial;
	private String materialDescription;
	private List<String> materialImageUrl;
	private Double quotedPrice;  
	
    private Integer userId;
    private String userName;
    private String userPhone;
    private String userEmail;
    private String profileImageUrl;
    private String shopName;
    private String shopAddress;
}
