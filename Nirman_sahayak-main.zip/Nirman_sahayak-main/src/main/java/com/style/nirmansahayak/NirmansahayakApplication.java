package com.style.nirmansahayak;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.core.env.PropertySource;

import java.util.Arrays;

@SpringBootApplication
@org.springframework.cache.annotation.EnableCaching
public class NirmansahayakApplication {

    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(NirmansahayakApplication.class, args);

        // Get Environment
        Environment env = context.getEnvironment();

        // Print All Loaded Beans
        System.out.println("=================================");
        System.out.println("=      LOADED BEANS IN CONTEXT   =");
        System.out.println("=================================");
        String[] beanNames = context.getBeanDefinitionNames();
        Arrays.sort(beanNames);
        for (String beanName : beanNames) {
            System.out.println(beanName);
        }

        // Print All Environment Properties
        System.out.println("=================================");
        System.out.println("=   ALL APPLICATION PROPERTIES   =");
        System.out.println("=================================");
        if (env instanceof ConfigurableEnvironment configurableEnvironment) {
            for (PropertySource<?> propertySource : configurableEnvironment.getPropertySources()) {
                System.out.println(propertySource.getName() + " => " + propertySource.toString());
            }
        }

        // Print Datasource Properties
        System.out.println("=============================");
        System.out.println("=   DATABASE CONFIGURATION   =");
        System.out.println("=============================");
        System.out.println("Datasource URL       : " + env.getProperty("spring.datasource.url"));
        System.out.println("Datasource Username  : " + env.getProperty("spring.datasource.username"));
        System.out.println("Datasource Password  : " + env.getProperty("spring.datasource.password"));
        System.out.println("=============================");
    }
}
