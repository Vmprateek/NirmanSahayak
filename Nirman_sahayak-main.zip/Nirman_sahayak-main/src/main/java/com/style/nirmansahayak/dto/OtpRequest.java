package com.style.nirmansahayak.dto;
import jakarta.validation.constraints.Size;
import lombok.Data;
import jakarta.validation.constraints.NotNull;

@Data
public class OtpRequest {

    @NotNull(message = "Phone number cannot be empty or null. ")
    @Size(min = 10, max = 10, message = "Phone number must be 10 characters including country code when provided")
    private String userPhone;
    
    @Size(min = 3, max = 100, message = "name must be 3 characters ")
    private String userName;
}

