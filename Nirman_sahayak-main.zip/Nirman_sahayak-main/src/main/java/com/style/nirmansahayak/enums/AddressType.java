package com.style.nirmansahayak.enums;

public enum AddressType {
    HOME,
    OFFICE,
    OTHER,
    SHOP;
}
