package com.style.nirmansahayak.model;


import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "material_name", indexes = {@Index(name = "idx_material_name", columnList = "materialName")})
public class MaterialName {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String materialName;
    private List<String> materialImageUrl;
    
    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "material_vendor_id", nullable = false)
    private MaterialVendor materialVendor;
}
