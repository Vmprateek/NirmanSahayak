package com.style.nirmansahayak.dto;

import lombok.Data;

@Data
public class ImageUpload {

	Integer id;
	String machineryName;
	String serviceName;
	String materialName;	
	String type;
}


