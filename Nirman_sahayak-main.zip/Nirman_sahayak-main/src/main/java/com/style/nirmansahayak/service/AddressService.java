//package com.style.nirmansahayak.service;
//
//import java.sql.PreparedStatement;
//import java.util.List;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.support.GeneratedKeyHolder;
//import org.springframework.stereotype.Service;
//import com.style.nirmansahayak.dto.AddressRequestDTO;
//import com.style.nirmansahayak.dto.AddressResponseDTO;
//import com.style.nirmansahayak.exception.ResourceNotFoundException;
//import com.style.nirmansahayak.model.Address;
//import com.style.nirmansahayak.repository.AddressRepository;
//import lombok.extern.slf4j.Slf4j;
//
//@Service
//@Slf4j
//public class AddressService {
//
//    @Autowired
//    private AddressRepository addressRepository;
//    
//    @Autowired
//    JdbcTemplate jdbcTemplate ;
//
//    public AddressResponseDTO saveAddress(AddressRequestDTO addressRequestDTO) {
//        log.info("Saving address: {}", addressRequestDTO);
//
//        String sql = "INSERT INTO address (address1, address2, city, pin, user_id) VALUES (?, ?, ?, ?, ?)";
//        GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
//
//        try {
//            jdbcTemplate.update(connection -> {
//                PreparedStatement ps = connection.prepareStatement(sql, new String[] {"address_id"}); // Ensure you're requesting only the primary key
//                ps.setString(1, addressRequestDTO.getAddress1());
//                ps.setString(2, addressRequestDTO.getAddress2());
//                ps.setString(3, addressRequestDTO.getCity());
//                ps.setInt(4, addressRequestDTO.getPin());
//                ps.setInt(5, addressRequestDTO.getUserId());
//                return ps;
//            }, keyHolder);
//
//            // Get the generated key and ensure it's a single key (address_id)
//            Number generatedKey = keyHolder.getKey();
//            if (generatedKey == null) {
//                throw new RuntimeException("Failed to retrieve the generated primary key.");
//            }
//
//            Integer addressId = generatedKey.intValue();
//            log.info("Address saved with ID: {}", addressId);
//
//            // Return response with generated address ID
//            return new AddressResponseDTO(addressId, addressRequestDTO);
//
//        } catch (Exception e) {
//            log.error("Error saving address: {}", addressRequestDTO, e);
//            throw new RuntimeException("Error saving address", e);
//        }
//    }
//
//    public List<Address> getAddresss() {
//        log.info("Fetching all addresses");
//        try {
//            return addressRepository.findAll();
//        } catch (Exception e) {
//            log.error("Error fetching all addresses", e);
//            throw e;
//        }
//    }
//
//    public Address getAddressById(Integer id) {
//        log.info("Fetching address by id: {}", id);
//        return addressRepository.findById(id)
//                .orElseThrow(() -> {
//                    log.error("Address not found with id: {}", id);
//                    return new ResourceNotFoundException("Address not found with id " + id);
//                });
//    }
//
//    public Address updateAddress(Address address) {
//        log.info("Updating address: {}", address);
//        try {
//            Address existingAddress = addressRepository.findById(address.getAddressId())
//                    .orElseThrow(() -> {
//                        log.error("Address not found with id: {}", address.getAddressId());
//                        return new ResourceNotFoundException("Address not found with id " + address.getAddressId());
//                    });
//
//            // Update fields
//            existingAddress.setLocality(address.getLocality());
//            existingAddress.setPostalCode(address.getPostalCode());
//            return addressRepository.save(existingAddress);
//        } catch (Exception e) {
//            log.error("Error updating address: {}", address, e);
//            throw e;
//        }
//    }
//
//    public String deleteAddress(int id) {
//        log.info("Deleting address by id: {}", id);
//        try {
//            Address existingAddress = addressRepository.findById(id)
//                    .orElseThrow(() -> {
//                        log.error("Address not found with id: {}", id);
//                        return new ResourceNotFoundException("Address not found with id " + id);
//                    });
//
//            addressRepository.delete(existingAddress);
//            log.info("Successfully deleted address with id: {}", id);
//            return "success";
//        } catch (Exception e) {
//            log.error("Error deleting address by id: {}", id, e);
//            throw e;
//        }
//    }
//
//    public Address findAddressByPin(int pin) {
//        log.info("Fetching address by pin: {}", pin);
//        try {
//            Address address = addressRepository.findByPin(pin);
//            if (address == null) {
//                log.error("Address not found with pin: {}", pin);
//                throw new ResourceNotFoundException("Address not found with pin " + pin);
//            }
//            return address;
//        } catch (Exception e) {
//            log.error("Error fetching address by pin: {}", pin, e);
//            throw e;
//        }
//    }
//
//    public List<Address> findAddressByCity(String city) {
//        log.info("Fetching addresses by city: {}", city);
//        try {
//            return addressRepository.findByCityLike(city);
//        } catch (Exception e) {
//            log.error("Error fetching addresses by city: {}", city, e);
//            throw e;
//        }
//    }
//}
