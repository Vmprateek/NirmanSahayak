package com.style.nirmansahayak.utils;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.security.Key;
import java.util.Date;

@Component
public class JwtUtil {

    private static final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256); // Secure random key
    private static final long EXPIRATION_TIME = 1000L * 60 * 60 * 24 * 365; // 1 year for access token (instead of 5 minutes)

    
    
   // private static final long EXPIRATION_TIME = 1000 * 60 * 2;
    
    /**
     * Generates an access JWT token for the given phone number.
     *
     * @param phoneNumber the phone number to include in the token
     * @return the generated JWT token
     */
    public String generateToken(String phoneNumber) {
        return Jwts.builder()
                .setSubject(phoneNumber)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME)) // 1 year expiration
                .signWith(key)
                .compact();
    }

    /**
     * Validates a JWT token.
     *
     * @param token the token to validate
     * @return true if the token is valid, false otherwise
     */
    public boolean validateToken(String token) {
        try {
            Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token);
            return true;
        } catch (JwtException e) {
            System.err.println("Invalid or expired JWT: " + e.getMessage());
            return false;
        }
    }

    /**
     * Extracts the phone number (subject) from a JWT token.
     *
     * @param token the token from which to extract the phone number
     * @return the phone number (subject) or null if extraction fails
     */
    public String extractPhoneNumber(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(key)
                    .build()
                    .parseClaimsJws(token)
                    .getBody()
                    .getSubject();  // Extract the phone number (subject)
        } catch (JwtException e) {
            System.err.println("Failed to extract phone number from JWT: " + e.getMessage());
            return null;
        }
    }

    /**
     * Checks if the token is expired.
     *
     * @param token the token to check
     * @return true if the token is expired, false otherwise
     */
    public boolean isTokenExpired(String token) {
        try {
            // Extract the expiration date from the token
            Date expirationDate = extractExpirationDate(token);
            
            // Check if the expiration date is null or the token has expired
            if (expirationDate == null) {
                System.err.println("Token does not contain a valid expiration date.");
                return true;  // Consider it expired if no valid expiration date is present
            }

            // Token is expired if the expiration date is before the current date
            return expirationDate.before(new Date());
        } catch (Exception e) {
            // Log the error for debugging purposes
            System.err.println("Error while checking token expiration: " + e.getMessage());
            
            // Consider the token expired or invalid if any exception occurs
            return true;
        }
    }

    /**
     * Extracts the expiration date from the JWT token.
     *
     * @param token the token to extract expiration date from
     * @return the expiration date of the token
     */
    private Date extractExpirationDate(String token) {
        Claims claims = Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
        return claims.getExpiration();  // Extract expiration date
    }
}
