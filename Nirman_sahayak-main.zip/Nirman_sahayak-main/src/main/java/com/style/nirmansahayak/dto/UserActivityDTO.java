package com.style.nirmansahayak.dto;

public class UserActivityDTO {
    private String machineryCategory;
    private String machinerySubCategory;
    private String machineryShopName;
    private String machineryShopAddress;

    private String materialCategory;
    private String materialSubCategory;
    private String materialShopName;
    private String materialShopAddress;

    private String workCategory;
    private String workSubCategory;
    private String workShopName;
    private String workShopAddress;

    private String openRequestCategory;
    private String openRequestSubCategory;
    private String openRequestShopName;
    private String openRequestShopAddress;

    // Constructor, Getters, and Setters
    public UserActivityDTO(String machineryCategory, String machinerySubCategory, String machineryShopName, String machineryShopAddress,
                           String materialCategory, String materialSubCategory, String materialShopName, String materialShopAddress,
                           String workCategory, String workSubCategory, String workShopName, String workShopAddress,
                           String openRequestCategory, String openRequestSubCategory, String openRequestShopName, String openRequestShopAddress) {
        this.machineryCategory = machineryCategory;
        this.machinerySubCategory = machinerySubCategory;
        this.machineryShopName = machineryShopName;
        this.machineryShopAddress = machineryShopAddress;
        this.materialCategory = materialCategory;
        this.materialSubCategory = materialSubCategory;
        this.materialShopName = materialShopName;
        this.materialShopAddress = materialShopAddress;
        this.workCategory = workCategory;
        this.workSubCategory = workSubCategory;
        this.workShopName = workShopName;
        this.workShopAddress = workShopAddress;
        this.openRequestCategory = openRequestCategory;
        this.openRequestSubCategory = openRequestSubCategory;
        this.openRequestShopName = openRequestShopName;
        this.openRequestShopAddress = openRequestShopAddress;
    }

    // Getters and Setters
}
