package com.style.nirmansahayak.model;

import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.style.nirmansahayak.enums.MaterialStatus;

import jakarta.persistence.*;


@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table
public class Material {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "material_sequence")
	@SequenceGenerator(name = "material_sequence", sequenceName = "material_sequence", initialValue = 1, allocationSize = 1)
    private Integer materialId;
	private String typeOfMaterial;
	private String materialDescription;
	private Double quotedPrice;
    @JsonFormat(pattern = "dd-mm-yyyy")
    private LocalDateTime postedDateTime;
    private String status;
    private List<String> materialImageUrl;
    private String type;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "userId")
    @ToString.Exclude
    @JsonBackReference
    private User user;
}



