package com.style.nirmansahayak.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.style.nirmansahayak.model.MachineryVendor;
import com.style.nirmansahayak.model.ServiceProvider;

@Repository
public interface MachineryVendorRepository extends JpaRepository<MachineryVendor, Integer> {

	@Query(value = """
            (
                SELECT 
                    mv.shop_name,
                    mv.complete_address,
                    mv.district, mv.state,
                    mv.country,
                    mv.postal_code,
                    u.user_name, 
                    u.user_phone,
                    u.user_email, 
                    u.profile_image_url,
                    u.experience, 
                    u.delivered_projects,
                    u.ongoing_projects
                FROM machinery_vendor mv
                JOIN machinery_name mn ON mv.machinery_vendor_id = mn.machinary_vendor_id  -- Corrected column name
                JOIN all_user u ON mv.user_id = u.user_id
                WHERE mn.machinery_name = :machineryName
                AND mv.postal_code = :postalCode
                LIMIT 5
            )
            UNION
            (
                SELECT 
                    mv.shop_name, 
                    mv.complete_address, 
                    mv.district, mv.state, 
                    mv.country, mv.postal_code,
                    u.user_name, 
                    u.user_phone, 
                    u.user_email, 
                    u.profile_image_url,
                    u.experience, 
                    u.delivered_projects, 
                    u.ongoing_projects
                FROM machinery_vendor mv
                JOIN machinery_name mn ON mv.machinery_vendor_id = mn.machinary_vendor_id  -- Corrected column name
                JOIN all_user u ON mv.user_id = u.user_id
                WHERE mn.machinery_name = :machineryName
                AND mv.district = (SELECT district FROM machinery_vendor WHERE postal_code = :postalCode LIMIT 1)
                LIMIT 15
            )
            """, nativeQuery = true)
List<Object[]> findByMachineryNameAndPostalOrDistrict(
        @Param("machineryName") String machineryName, 
        @Param("postalCode") Integer postalCode);

@Query(value = "SELECT * FROM machinery_vendor WHERE user_id = :userId LIMIT 1", nativeQuery = true)
	Optional<MachineryVendor> findByUserId(Integer userId);

}
