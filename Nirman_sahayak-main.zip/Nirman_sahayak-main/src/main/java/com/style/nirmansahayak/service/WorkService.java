

package com.style.nirmansahayak.service;

import java.time.LocalDateTime;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.style.nirmansahayak.dto.PostalDetails;
import com.style.nirmansahayak.model.Work;
import com.style.nirmansahayak.repository.WorkRepository;
import com.style.nirmansahayak.response.WorkResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class WorkService {

    @Autowired
    private WorkRepository workRepository;
    @Autowired
    PostalService postalService;
    public Work saveWork(Work work) {
        long startTime = System.currentTimeMillis();
        log.info("Method: saveWork, Layer: Service, Request: Saving work: {}", work);

        try {
        	
        	Mono<PostalDetails> data = postalService.getPostalDetails(work.getPostalCode());
        	PostalDetails postalDetails = data.block();

        	// Set the district and state values in the serviceProviderInfo object
        	if (postalDetails != null) {
        	    work.setDistrict(postalDetails.getDistrict());
        	    work.setState(postalDetails.getState());
        	} else {
        	    work.setDistrict("Unknown");
        	    work.setState("Unknown");
        	}

        	work.setCountry("India");
        	work.setPostedDateTime(LocalDateTime.now());
        	work.setStatus("ACTIVE");
            Work savedWork = workRepository.save(work);
            log.info("Method: saveWork, Layer: Service, Success: Work saved with ID: {}", savedWork.getWorkId());
            return savedWork;
        } catch (Exception e) {
            log.error("Method: saveWork, Layer: Service, Error saving work: {}", work, e);
            throw new RuntimeException("Failed to save work due to internal error", e); // Providing a meaningful exception message
        } finally {
            long endTime = System.currentTimeMillis();
            log.info("Method: saveWork, Layer: Service, Execution Time: {} ms", (endTime - startTime));
        }
    }

    public List<WorkResponse> getAllWrokByLocation(Integer postalCode ,String typeOfWork) { 	
        return workRepository.findByPostalCodeAndTypeOfWork(postalCode, typeOfWork);
    }

    public boolean deleteWork(Integer id) {
        log.info("Method: deleteWork, Layer: Service, Request: Deleting work with ID: {}", id);

        return workRepository.findById(id).map(work -> {
            workRepository.deleteById(id);
            log.info("Method: deleteWork, Layer: Service, Success: Work deleted with ID: {}", id);
            return true;
        }).orElseGet(() -> {
            log.warn("Method: deleteWork, Layer: Service, Warning: Work with ID {} not found", id);
            return false;
        });
    }

  
}
