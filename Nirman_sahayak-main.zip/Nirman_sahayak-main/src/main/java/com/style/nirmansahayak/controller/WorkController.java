package com.style.nirmansahayak.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.style.nirmansahayak.dto.MaterialDTO;
import com.style.nirmansahayak.dto.WorkRequest;
import com.style.nirmansahayak.model.Work;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.response.WorkResponse;
import com.style.nirmansahayak.service.S3Service;
import com.style.nirmansahayak.service.WorkService;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;

/**
 * Controller to manage Work-related operations.
 */
@CrossOrigin
@RestController
@Slf4j
@RequestMapping("/api/v1")
public class WorkController {

	@Autowired
	private WorkService workService;

	@Autowired
	private S3Service s3Service;
	ObjectMapper objectMapper = new ObjectMapper();

	@PostMapping(value = "/saveWork")
	public ResponseEntity<?> saveWork(
            @RequestPart("work") String workJson,
            @RequestPart(required = false) List<MultipartFile> files) {
		log.info("Method: saveWork, Layer: Controller, Request: Work data for user: {}", workJson);
		try {

			Work work = objectMapper.readValue(workJson, Work.class);
			List<String> fileUrls = new ArrayList<>();
			if (files != null && !files.isEmpty()) {
			    for (MultipartFile file : files) {
			        if (file != null && !file.isEmpty()) {  // Check if each file is not null or empty
			            String fileUrl = s3Service.uploadFile(file);
			            if (fileUrl != null) {  // Check if fileUrl is not null before adding it to the list
			                fileUrls.add(fileUrl);
			            }
			        }
			    }
			} else {
			    // Handle the case where files is null or empty
			    System.out.println("No files provided for upload.");
			}
			work.setWorkImageUrl(fileUrls);
			workService.saveWork(work);
			return ResponseEntity.ok(ResponseBuilder.buildResponse(HttpStatus.OK, ResponseCodeEnum.SUCCESS,
					"Work saved successfully", work));

		} catch (Exception e) {
			log.error("Method: saveWork, Layer: Controller, Error saving work for user: {}", workJson, e);
			return ResponseBuilder.buildResponse(HttpStatus.INTERNAL_SERVER_ERROR,
					ResponseCodeEnum.INTERNAL_SERVER_ERROR, "Error saving work", null);
		}
	}

	
	@GetMapping("/findAllWorkByLocation")
	public ResponseEntity<?> searchWorks(@RequestParam(required = false) Integer postalCode,@RequestParam(required = false)String typeOfWork) {
	     List<WorkResponse> works = workService.getAllWrokByLocation(postalCode,typeOfWork);

	    if (works.isEmpty()) {
	        return ResponseBuilder.buildResponse(
	                HttpStatus.OK,
	                ResponseCodeEnum.NO_CONTENT,
	                "No work found for the given postal code.",
	                Collections.emptyList()
	        );
	    }

	    return ResponseBuilder.buildResponse(
	            HttpStatus.OK,
	            ResponseCodeEnum.SUCCESS,
	            "Work data fetched successfully.",
	            works
	    );
	}

	@DeleteMapping("/deleteWork/{id}")
	public ResponseEntity<?> deleteWork(@PathVariable Integer id) {
	    log.info("Method: deleteWork, Layer: Controller, Request: Deleting work with ID: {}", id);
	    try {
	        boolean isDeleted = workService.deleteWork(id);
	        if (isDeleted) {
	            return ResponseBuilder.buildResponse(
	                    HttpStatus.OK,
	                    ResponseCodeEnum.SUCCESS,
	                    "Work deleted successfully",
	                    null
	            );
	        } else {
	            return ResponseBuilder.buildResponse(
	                    HttpStatus.NOT_FOUND,
	                    ResponseCodeEnum.NOT_FOUND,
	                    "Work not found with ID: " + id,
	                    null
	            );
	        }
	    } catch (Exception e) {
	        log.error("Method: deleteWork, Layer: Controller, Error deleting work with ID: {}", id, e);
	        return ResponseBuilder.buildResponse(
	                HttpStatus.INTERNAL_SERVER_ERROR,
	                ResponseCodeEnum.INTERNAL_SERVER_ERROR,
	                "Failed to delete work due to internal error",
	                null
	        );
	    }
	}

	
	
}
