package com.style.nirmansahayak.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.style.nirmansahayak.enums.ResponseCodeEnum;
import com.style.nirmansahayak.response.ActivityResponse;
import com.style.nirmansahayak.response.ResponseBuilder;
import com.style.nirmansahayak.service.MyActivityService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/api/v1")
public class MyActivityController {

    @Autowired
    private MyActivityService myActivityService;

    @GetMapping("/getAllActivity/{userId}")
    public ResponseEntity<?> getUserActivities(@PathVariable Long userId) {
        try {
            log.info("Fetching activities for user ID: {}", userId);

            // Fetching activities using the service
            ActivityResponse response = myActivityService.getUserActivities(userId);

            log.info("Fetched activities successfully for user ID: {}", userId);

            // Return a successful response
            return ResponseBuilder.buildResponse(
                    HttpStatus.OK,
                    ResponseCodeEnum.SUCCESS,
                    "All activities fetched successfully.",
                    response
            );
        } catch (Exception e) {
            log.error("Error fetching activities for user ID: {}", userId, e);
            return ResponseBuilder.buildResponse(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ResponseCodeEnum.INTERNAL_SERVER_ERROR,
                    "An error occurred while fetching activities.",
                    null
            );
        }
    }
}
